Ac = 0.894427190999916;
wc = 1.5008;
tolUp2 = 1e10; % 3e-3;
deltaQ = pi/1000*3;
Qgap = 1;
sFac = 2.8;
sFac2 = 3.1;

fig1002Y1 = 0.65;
fig1002Y2 = 2.35;

facShrinkx = 1/1.2;
facShrinky = 1/1.2;
dx1 = 0.0556*facShrinkx;
x1 = 0.5-dx1;
x2 = 0.5+dx1;
dy1 = 0.127*facShrinky;
y1 = 1.5-dy1;
y2 = 1.5+dy1;


lineWidth = 1;
markerSize = 10;
markerSize2 = 20*sqrt(0.75);
markerSize3 = 30;

colors = zeros(6,3);
colors(1,1:3) = [92 172 238]/256;
colors(3,1:3) = [28 134 238]/256; % colors(2,1:3) = [28 134 238]/256;
colors(2,1:3) = [0 0 255]/256; % colors(3,1:3) = [0 0 255]/256;
colors(4,1:3) = [238 0 0]/256;
colors(5,1:3) = [238 106 167]/256; % colors(5,1:3) = [238 106 167]/256;
colors(6,1:3) = [255 181 197]/256; % colors(6,1:3) = [255 181 197]/256;

tolA1 = 3e-3;
tolA2 = 2e-2;
e0 = 1.5;
dq2Pi = 0.5/200; % wave number in units of 2pi   0.5 corresponds to pi
polyOrder  = 4;
polyOrder1 = polyOrder;
polyOrder2 = polyOrder;

sw = -1;

pmmmSswitch = 1;
NNMAtot = nan(30,11); % 1:A, 2:q, 3:w, 4:InterPhase, 5,6,7,8:IntraPhase, 9,10:pp,pm,mp,mm
labelTot = 0;
% Asample = [0.4 0.85 Ac 0.95 1.1]; %[0.2 0.85 Ac 0.95 1.1];
Asample = [0.4 0.8 Ac 1 1.1]; %[0.2 0.85 Ac 0.95 1.1];

coloring = nan(size(Asample,2),3);
coloring(1,:) = [0 1 1];
coloring(2,:) = [1 0 1];
coloring(3,:) = [0 0 0];
coloring(4,:) = [0 0 1];
coloring(5,:) = [1 0 0];
coloring(6,:) = [1 0.6 0];

for n3 = 1:size(Asample,2)
    
    waveNumRec = zeros(2,2);
    labelWN = 0;
    
    n2Rec = nan(500,1);
    n2RecLabel = 0;
    
    NNMAtemp2 = nan(30,11); % 1:A, 2:q, 3:w, 4:InterPhase, 5,6,7,8:IntraPhase, 9,10:pp,pm,mp,mm
    A = Asample(n3);
    tola1 = A*tolA1;
    tola2 = A*tolA2;
    
    label = 0;
    label1 = 0;
    label2 = 0;
    % filename1 = strcat('.\Kagome_lattice\Kagome_Diode\Kagome_diode_fine_in_0_125_',num2str(i));
    % n2 = 0;
    for n2 = 1:1000
        % while 1
        % n2 = n2+1;
        if n2 == 1
            q = abs(1/2-1/3);
            filename = strcat('NNM1_3mm');
        elseif n2 == 2
            q = abs(1/2-1/5);
            filename = strcat('NNM1_5mm');
        elseif n2 == 3
            q = abs(1/2-2/5);
            filename = strcat('NNM2_5mm');
        elseif n2 == 4
            q = abs(1/2-1/7);
            filename = strcat('NNM1_7mm');
        elseif n2 == 5
            q = abs(1/2-2/7);
            filename = strcat('NNM2_7mm');
        elseif n2 == 6
            q = abs(1/2-3/7);
            filename = strcat('NNM3_7mm');
        elseif n2 == 7
            q = abs(1/2-1/8);
            filename = strcat('NNM1_8mm');
        elseif n2 == 8
            q = abs(1/2-1/9);
            filename = strcat('NNM1_9mm');
        elseif n2 == 9
            q = abs(1/2-2/9);
            filename = strcat('NNM2_9mm');
        elseif n2 == 10
            q = abs(1/2-4/9);
            filename = strcat('NNM4_9mm');
        elseif n2 == 11
            q = abs(1/2-1/11);
            filename = strcat('NNM1_11mm');
        elseif n2 == 12
            q = abs(1/2-2/11);
            filename = strcat('NNM2_11mm');
        elseif n2 == 13
            q = abs(1/2-3/11);
            filename = strcat('NNM3_11mm');
        elseif n2 == 14
            q = abs(1/2-4/11);
            filename = strcat('NNM4_11mm');
        elseif n2 == 15
            q = abs(1/2-5/11);
            filename = strcat('NNM5_11mm');
        elseif n2 == 16
            q = abs(1/2-1/13);
            filename = strcat('NNM1_13mm');
        elseif n2 == 17
            q = abs(1/2-2/13);
            filename = strcat('NNM2_13mm');
        elseif n2 == 18
            q = abs(1/2-3/13);
            filename = strcat('NNM3_13mm');
        elseif n2 == 19
            q = abs(1/2-4/13);
            filename = strcat('NNM4_13mm');
        elseif n2 == 20
            q = abs(1/2-5/13);
            filename = strcat('NNM5_13mm');
        elseif n2 == 21
            q = abs(1/2-2/15);
            filename = strcat('NNM2_15mm');
        elseif n2 == 22
            q = abs(1/2-4/15);
            filename = strcat('NNM4_15mm');
        elseif n2 == 23
            q = abs(1/2-7/15);
            filename = strcat('NNM7_15mm');
        elseif n2 == 24
            q = abs(1/2-1/15);
            filename = strcat('NNM1_15mm');
        elseif n2 == 25
            q = abs(1/2-1/12);
            filename = strcat('NNM1_12mm');
        elseif n2 == 26
            q = abs(1/2-5/12);
            filename = strcat('NNM5_12mm');
        elseif n2 == 27
            % continue;
            q = abs(1/2-1/16);
            filename = strcat('NNM1_16mm');
        elseif n2 == 28
            % continue;
            q = abs(1/2-7/16);
            filename = strcat('NNM7_16mm');
        elseif n2 == 29
            q = abs(1/2-3/20);
            filename = strcat('NNM3_20mm');
        elseif n2 == 30
            q = abs(1/2-5/24);
            filename = strcat('NNM5_24mm');
        elseif n2 == 31
            q = abs(1/2-9/28);
            filename = strcat('NNM9_28mm');
        elseif n2 == 32
            q = abs(1/2-5/23);
            filename = strcat('NNM5_23mm');
        elseif n2 == 33
            q = abs(1/2-5/29);
            filename = strcat('NNM5_29mm');
        elseif n2 == 34
            q = abs(1/2-6/29);
            filename = strcat('NNM6_29mm');
        elseif n2 == 35
            q = 0;
            filename = strcat('NNM0mp');
        elseif n2 == 36
            q = 1/2;
            filename = strcat('NNM1_2mp');
        elseif n2 == 37
            q = 1/3;
            filename = strcat('NNM1_3mp');
        elseif n2 == 38
            q = 1/4;
            filename = strcat('NNM1_4mp');
        elseif n2 == 39
            q = 1/5;
            filename = strcat('NNM1_5mp');
        elseif n2 == 40
            q = 1/7;
            filename = strcat('NNM1_7mp');
        elseif n2 == 41
            q = 2/5;
            filename = strcat('NNM2_5mp');
        elseif n2 == 42
            q = 2/7;
            filename = strcat('NNM2_7mp');
        elseif n2 == 43
            q = 2/9;
            filename = strcat('NNM2_9mp');
        elseif n2 == 44
            q = 2/11;
            filename = strcat('NNM2_11mp');
        elseif n2 == 45
            q = 3/7;
            filename = strcat('NNM3_7mp');
        elseif n2 == 46
            q = 3/11;
            filename = strcat('NNM3_11mp');
        elseif n2 == 47
            q = 3/13;
            filename = strcat('NNM3_13mp');
        elseif n2 == 48
            q = 4/13;
            filename = strcat('NNM4_13mp');
        elseif n2 == 49
            q = 4/17;
            filename = strcat('NNM4_17mp');
        elseif n2 == 50
            q = 5/11;
            filename = strcat('NNM5_11mp');
        elseif n2 == 51
            q = 5/13;
            filename = strcat('NNM5_13mp');
        elseif n2 == 52
            q = 0;
            filename = strcat('NNM0pp');
        elseif n2 == 53
            q = 1/2;
            filename = strcat('NNM1_2pp');
        elseif n2 == 54
            q = 1/3;
            filename = strcat('NNM1_3pp');
        elseif n2 == 55
            q = 1/4;
            filename = strcat('NNM1_4pp');
        elseif n2 == 56
            q = 1/5;
            filename = strcat('NNM1_5pp');
        elseif n2 == 57
            q = 2/5;
            filename = strcat('NNM2_5pp');
        elseif n2 == 58
            q = 1/7;
            filename = strcat('NNM1_7pp');
        elseif n2 == 59
            q = 2/7;
            filename = strcat('NNM2_7pp');
        elseif n2 == 60
            q = 3/7;
            filename = strcat('NNM3_7pp');
        elseif n2 == 61
            q = 1/8;
            filename = strcat('NNM1_8pp');
        elseif n2 == 62
            q = 1/9;
            filename = strcat('NNM1_9pp');
        elseif n2 == 63
            q = 2/9;
            filename = strcat('NNM2_9pp');
        elseif n2 == 64
            q = 4/9;
            filename = strcat('NNM4_9pp');
        elseif n2 == 65
            q = 1/11;
            filename = strcat('NNM1_11pp');
        elseif n2 == 66
            q = 2/11;
            filename = strcat('NNM2_11pp');
        elseif n2 == 67
            q = 3/11;
            filename = strcat('NNM3_11pp');
        elseif n2 == 68
            q = 4/11;
            filename = strcat('NNM4_11pp');
        elseif n2 == 69
            q = 5/11;
            filename = strcat('NNM5_11pp');
        elseif n2 == 70
            continue;
            %             q = 1/13;
            %             filename = strcat('NNM1_13pp');
        elseif n2 == 71
            q = 2/13;
            filename = strcat('NNM2_13pp');
        elseif n2 == 72
            q = 3/13;
            filename = strcat('NNM3_13pp');
        elseif n2 == 73
            q = 4/13;
            filename = strcat('NNM4_13pp');
        elseif n2 == 74
            q = 5/13;
            filename = strcat('NNM5_13pp');
        elseif n2 == 75
            q = 6/13;
            filename = strcat('NNM6_13pp');
        elseif n2 == 76
            q = 1/15;
            filename = strcat('NNM1_15pp');
        elseif n2 == 77
            continue;
            %             q = 2/15;
            %             filename = strcat('NNM2_15pp');
        elseif n2 == 78
            q = 7/15;
            filename = strcat('NNM7_15pp');
        elseif n2 == 79
            q = abs(1/2-1/3);
            filename = strcat('NNM1_3pm');
        elseif n2 == 80
            q = abs(1/2-1/5);
            filename = strcat('NNM1_5pm');
        elseif n2 == 81
            q = abs(1/2-2/5);
            filename = strcat('NNM2_5pm');
        elseif n2 == 82
            q = abs(1/2-1/7);
            filename = strcat('NNM1_7pm');
        elseif n2 == 83
            q = abs(1/2-1/8);
            filename = strcat('NNM1_8pm');
        elseif n2 == 84
            q = abs(1/2-1/9);
            filename = strcat('NNM1_9pm');
        elseif n2 == 85
            q = abs(1/2-1/16);
            filename = strcat('NNM1_16pm');
        elseif n2 == 86
            q = abs(1/2-2/7);
            filename = strcat('NNM2_7pm');
        elseif n2 == 87
            q = abs(1/2-3/7);
            filename = strcat('NNM3_7pm');
        elseif n2 == 88
            q = abs(1/2-2/9);
            filename = strcat('NNM2_9pm');
        elseif n2 == 89
            q = abs(1/2-2/13);
            filename = strcat('NNM2_13pm');
        elseif n2 == 90
            q = abs(1/2-3/11);
            filename = strcat('NNM3_11pm');
        elseif n2 == 91
            q = abs(1/2-3/20);
            filename = strcat('NNM3_20pm');
        elseif n2 == 92
            q = abs(1/2-3/29);
            filename = strcat('NNM3_29pm');
        elseif n2 == 93
            q = abs(1/2-4/29);
            filename = strcat('NNM4_29pm');
        elseif n2 == 94
            q = abs(1/2-5/24);
            filename = strcat('NNM5_24pm');
        elseif n2 == 95
            q = abs(1/2-5/29);
            filename = strcat('NNM5_29pm');
        elseif n2 == 96
            q = abs(1/2-6/29);
            filename = strcat('NNM6_29pm');
        elseif n2 == 97
            q = abs(1/2-7/16);
            filename = strcat('NNM7_16pm');
        elseif n2 == 98
            q = abs(1/2-11/29);
            filename = strcat('NNM11_29pm');
        elseif n2 == 99
            continue;
            %             q = abs(1/2-13/29);
            %             filename = strcat('NNM13_29pm');
        elseif n2 == 100
            q = 9/19;
            filename = strcat('NNM9_19mp');
        elseif n2 == 101
            q = 4/19;
            filename = strcat('NNM4_19pp');
        elseif n2 == 102
            q = 5/23;
            filename = strcat('NNM5_23pp');
        elseif n2 == 103
            q = 7/23;
            filename = strcat('NNM7_23pp');
        elseif n2 == 104
            q = 8/23;
            filename = strcat('NNM8_23pp');
        elseif n2 == 105
            q = 9/23;
            filename = strcat('NNM9_23pp');
        elseif n2 == 106
            q = 10/23;
            filename = strcat('NNM10_23pp');
        elseif n2 == 107
            q = 2/29;
            filename = strcat('NNM2_29pp');
        elseif n2 == 108
            q = 6/29;
            filename = strcat('NNM6_29pp');
        elseif n2 == 109
            q = 8/29;
            filename = strcat('NNM8_29pp');
        elseif n2 == 110
            q = 9/29;
            filename = strcat('NNM9_29pp');
        elseif n2 == 111
            q = 10/29;
            filename = strcat('NNM10_29pp');
        elseif n2 == 112
            q = 9/31;
            filename = strcat('NNM9_31pp');
        elseif n2 == 113
            q = 10/31;
            filename = strcat('NNM10_31pp');
        elseif n2 == 114
            q = 11/31;
            filename = strcat('NNM11_31pp');
        elseif n2 == 115
            q = 12/31;
            filename = strcat('NNM12_31pp');
        elseif n2 == 116
            q = 13/31;
            filename = strcat('NNM13_31pp');
        elseif n2 == 117
            q = 14/31;
            filename = strcat('NNM14_31pp');
        elseif n2 == 118
            q = 14/29;
            filename = strcat('NNM14_29pp');
        elseif n2 == 119
            q = 15/31;
            filename = strcat('NNM15_31pp');
        elseif n2 == 120
            q = 13/29;
            filename = strcat('NNM13_29pp');
        elseif n2 == 121
            q = 17/35;
            filename = strcat('NNM17_35pp');
        elseif n2 == 122
            q = 25/51;
            filename = strcat('NNM25_51pp');
        elseif n2 == 123
            q = 37/75;
            filename = strcat('NNM37_75pp');
        elseif n2 == 124
            q = 10/21;
            filename = strcat('NNM10_21mp');
        elseif n2 == 125
            q = 19/39;
            filename = strcat('NNM19_39mp');
        elseif n2 == 126
            q = 9/19;
            filename = strcat('NNM9_19pp');
        elseif n2 == 127
            q = 27/55;
            filename = strcat('NNM27_55mp');
        elseif n2 == 128
            q = 28/57;
            filename = strcat('NNM28_57mp');
        elseif n2 == 129
            q = 37/75;
            filename = strcat('NNM37_75mp');
        elseif n2 == 130
            q = abs(1/2-1/11);
            filename = strcat('NNM1_11pm');
        elseif n2 == 131
            q = abs(1/2-1/13);
            filename = strcat('NNM1_13pm');
        elseif n2 == 132
            q = abs(1/2-1/15);
            filename = strcat('NNM1_15pm');
        elseif n2 == 133
            q = abs(1/2-1/17);
            filename = strcat('NNM1_17pm');
        elseif n2 == 134
            q = abs(1/2-1/19);
            filename = strcat('NNM1_19pm');
        elseif n2 == 135
            q = abs(1/2-1/21);
            filename = strcat('NNM1_21pm');
        elseif n2 == 136
            q = abs(1/2-1/23);
            filename = strcat('NNM1_23pm');
        elseif n2 == 137
            q = abs(1/2-1/25);
            filename = strcat('NNM1_25pm');
        elseif n2 == 138
            q = abs(1/2-1/27);
            filename = strcat('NNM1_27pm');
        elseif n2 == 139
            q = abs(1/2-1/31);
            filename = strcat('NNM1_31pm');
        elseif n2 == 140
            q = abs(1/2-1/33);
            filename = strcat('NNM1_33pm');
        elseif n2 == 141
            q = abs(1/2-1/35);
            filename = strcat('NNM1_35pm');
        elseif n2 == 142
            q = abs(1/2-1/37);
            filename = strcat('NNM1_37pm');
        elseif n2 == 143
            q = abs(1/2-1/51);
            filename = strcat('NNM1_51pm');
        elseif n2 == 144
            q = abs(1/9);
            filename = strcat('NNM1_9mp');
        elseif n2 == 145
            q = abs(1/2-4/9);
            filename = strcat('NNM4_9pm');
        elseif n2 ==146
            q = abs(1/2-5/11);
            filename = strcat('NNM5_11pm');
        elseif n2 == 147
            q = abs(1/2-9/19);
            filename = strcat('NNM9_19pm');
        elseif n2 == 148
            q = abs(1/2-10/21);
            filename = strcat('NNM10_21pm');
        elseif n2 == 149
            q = abs(1/2-11/23);
            filename = strcat('NNM11_23pm');
        elseif n2 == 150
            q = 1/19;
            filename = strcat('NNM1_19pp');
        elseif n2 == 151
            q = 2/19;
            filename = strcat('NNM2_19pp');
        elseif n2 == 152
            q = 3/19;
            filename = strcat('NNM3_19pp');
        elseif n2 == 153
            q = 5/19;
            filename = strcat('NNM5_19pp');
        elseif n2 == 154
            q = 6/19;
            filename = strcat('NNM6_19pp');
        elseif n2 == 155
            q = 1/13;
            filename = strcat('NNM1_13pp');
        elseif n2 == 156
            q = 1/17;
            filename = strcat('NNM1_17pp');
        elseif n2 == 157
            q = 4/9;
            filename = strcat('NNM4_9mp');
        elseif n2 == 158
            q = 1/8;
            filename = strcat('NNM1_8mp');
        elseif n2 == 159
            q = 1/12;
            filename = strcat('NNM1_12mp');
        elseif n2 == 160
            q = 1/13;
            filename = strcat('NNM1_13mp');
        elseif n2 == 161
            q = 1/11;
            filename = strcat('NNM1_11mp');
        elseif n2 == 162
            q = 6/13;
            filename = strcat('NNM6_13mp');
        elseif n2 == 163
            q = 1/15;
            filename = strcat('NNM1_15mp');
        elseif n2 == 164
            q = 2/15;
            filename = strcat('NNM2_15mp');
        elseif n2 == 165
            q = 4/15;
            filename = strcat('NNM4_15mp');
        elseif n2 == 166
            q = 7/15;
            filename = strcat('NNM7_15mp');
        elseif n2 == 167
            q = 1/16;
            filename = strcat('NNM1_16mp');
        elseif n2 == 168
            q = 3/16;
            filename = strcat('NNM3_16mp');
        elseif n2 == 169
            q = 1/17;
            filename = strcat('NNM1_17mp');
        elseif n2 == 170
            q = 2/17;
            filename = strcat('NNM2_17mp');
        elseif n2 == 171
            q = 3/17;
            filename = strcat('NNM3_17mp');
        elseif n2 == 172
            q = 4/17;
            filename = strcat('NNM4_17mp');
        elseif n2 == 173
            q = 5/17;
            filename = strcat('NNM5_17mp');
        elseif n2 == 174
            q = 6/17;
            filename = strcat('NNM6_17mp');
        elseif n2 == 175
            q = 8/17;
            filename = strcat('NNM8_17mp');
        elseif n2 == 176
            q = 1/19;
            filename = strcat('NNM1_19mp');
        elseif n2 == 177
            q = 2/19;
            filename = strcat('NNM2_19mp');
        elseif n2 == 178
            q = 3/19;
            filename = strcat('NNM3_19mp');
        elseif n2 == 179
            q = 4/19;
            filename = strcat('NNM4_19mp');
        elseif n2 == 180
            q = 5/19;
            filename = strcat('NNM5_19mp');
        elseif n2 == 181
            q = 6/19;
            filename = strcat('NNM6_19mp');
        elseif n2 == 182
            q = 1/21;
            filename = strcat('NNM1_21mp');
        elseif n2 == 183
            q = 2/21;
            filename = strcat('NNM2_21mp');
        elseif n2 == 184
            q = 4/21;
            filename = strcat('NNM4_21mp');
        elseif n2 == 185
            q = 5/21;
            filename = strcat('NNM5_21mp');
        elseif n2 == 186
            q = 1/23;
            filename = strcat('NNM1_23mp');
        elseif n2 == 187
            q = 2/23;
            filename = strcat('NNM2_23mp');
        elseif n2 == 188
            q = 3/23;
            filename = strcat('NNM3_23mp');
        elseif n2 == 189
            q = 4/23;
            filename = strcat('NNM4_23mp');
        elseif n2 == 190
            q = 4/11;
            filename = strcat('NNM4_11mp');
        elseif n2 == 191
            q = 2/13;
            filename = strcat('NNM2_13mp');
        elseif n2 == 192
            q = 1/45;
            filename = strcat('NNM1_45mp');
        elseif n2 == 193
            q = 1/55;
            filename = strcat('NNM1_55mp');
        elseif n2 == 194
            q = 1/75;
            filename = strcat('NNM1_75mp');
        elseif n2 == 195
            q = 3/20;
            filename = strcat('NNM3_20mp');
        elseif n2 == 196
            q = 8/39;
            filename = strcat('NNM8_39mp');
        elseif n2 == 197
            q = 30/61;
            filename = strcat('NNM30_61mp');
        elseif n2 == 198
            q = 45/91;
            filename = strcat('NNM45_91mp');
        elseif n2 == 199
            q = 65/131;
            filename = strcat('NNM65_131mp');
        elseif n2 == 200
            q = 65/131;
            filename = strcat('NNM65_131pp');
        elseif n2 == 201
            q = 45/91;
            filename = strcat('NNM45_91pp');
        elseif n2 == 202
            q = 30/61;
            filename = strcat('NNM30_61pp');
        elseif n2 == 203
            q = 27/55;
            filename = strcat('NNM27_55pp');
        elseif n2 == 204
            q = 2/15;
            filename = strcat('NNM2_15pp');
        elseif n2 == 205
            q = 4/15;
            filename = strcat('NNM4_15pp');
        elseif n2 == 206
            q = 2/17;
            filename = strcat('NNM2_17pp');
        elseif n2 == 207
            q = 3/17;
            filename = strcat('NNM3_17pp');
        elseif n2 == 208
            q = 4/17;
            filename = strcat('NNM4_17pp');
        elseif n2 == 209
            q = 5/17;
            filename = strcat('NNM5_17pp');
        elseif n2 == 210
            q = 6/17;
            filename = strcat('NNM6_17pp');
        elseif n2 == 211
            q = 7/17;
            filename = strcat('NNM7_17pp');
        elseif n2 == 212
            q = 8/17;
            filename = strcat('NNM8_17pp');
        elseif n2 == 213
            q = 7/19;
            filename = strcat('NNM7_19pp');
        elseif n2 == 214
            q = 8/19;
            filename = strcat('NNM8_19pp');
        elseif n2 == 215
            q = 1/20;
            filename = strcat('NNM1_20pp');
        elseif n2 == 216
            q = 3/20;
            filename = strcat('NNM3_20pp');
        elseif n2 == 217
            q = 1/21;
            filename = strcat('NNM1_21pp');
        elseif n2 == 218
            q = 2/21;
            filename = strcat('NNM2_21pp');
        elseif n2 == 219
            q = 4/21;
            filename = strcat('NNM4_21pp');
        elseif n2 == 220
            q = 5/21;
            filename = strcat('NNM5_21pp');
        elseif n2 == 221
            q = 8/21;
            filename = strcat('NNM8_21pp');
        elseif n2 == 222
            q = 10/21;
            filename = strcat('NNM10_21pp');
        elseif n2 == 223
            q = 1/23;
            filename = strcat('NNM1_23pp');
        elseif n2 == 224
            q = 2/23;
            filename = strcat('NNM2_23pp');
        elseif n2 == 225
            q = 3/23;
            filename = strcat('NNM3_23pp');
        elseif n2 == 226
            q = 4/23;
            filename = strcat('NNM4_23pp');
        elseif n2 == 227
            q = 6/23;
            filename = strcat('NNM6_23pp');
        elseif n2 == 228
            q = 11/23;
            filename = strcat('NNM11_23pp');
        elseif n2 == 229
            q = 1/29;
            filename = strcat('NNM1_29pp');
        elseif n2 == 230
            q = 3/29;
            filename = strcat('NNM3_29pp');
        elseif n2 == 231
            q = 4/29;
            filename = strcat('NNM4_29pp');
        elseif n2 == 232
            q = 5/29;
            filename = strcat('NNM5_29pp');
        elseif n2 == 233
            q = 7/29;
            filename = strcat('NNM7_29pp');
        elseif n2 == 234
            q = 1/20;
            filename = strcat('NNM1_20mp');
        elseif n2 == 235
            q = 5/23;
            filename = strcat('NNM5_23mp');
        elseif n2 == 236
            q = 6/23;
            filename = strcat('NNM6_23mp');
        elseif n2 == 237
            q = 7/23;
            filename = strcat('NNM7_23mp');
        elseif n2 == 238
            q = 8/23;
            filename = strcat('NNM8_23mp');
        elseif n2 == 239
            q = 9/23;
            filename = strcat('NNM9_23mp');
        elseif n2 == 240
            q = 11/23;
            filename = strcat('NNM11_23mp');
        elseif n2 == 241
            q = 1/25;
            filename = strcat('NNM1_25mp');
        elseif n2 == 242
            q = 2/25;
            filename = strcat('NNM2_25mp');
        elseif n2 == 243
            q = 3/25;
            filename = strcat('NNM3_25mp');
        elseif n2 == 244
            q = 4/25;
            filename = strcat('NNM4_25mp');
        elseif n2 == 245
            q = 6/25;
            filename = strcat('NNM6_25mp');
        elseif n2 == 246
            q = 7/25;
            filename = strcat('NNM7_25mp');
        elseif n2 == 247
            q = 8/25;
            filename = strcat('NNM8_25mp');
        elseif n2 == 248
            q = 9/25;
            filename = strcat('NNM9_25mp');
        elseif n2 == 249
            q = 12/25;
            filename = strcat('NNM12_25mp');
        elseif n2 == 250
            q = 13/27;
            filename = strcat('NNM13_27mp');
        elseif n2 == 251
            q = 11/27;
            filename = strcat('NNM11_27mp');
        elseif n2 == 252
            q = 10/27;
            filename = strcat('NNM10_27mp');
        elseif n2 == 253
            q = 7/27;
            filename = strcat('NNM7_27mp');
        elseif n2 == 254
            q = 5/27;
            filename = strcat('NNM5_27mp');
        elseif n2 == 255
            q = 4/27;
            filename = strcat('NNM4_27mp');
        elseif n2 == 256
            q = 2/27;
            filename = strcat('NNM2_27mp');
        elseif n2 == 257
            q = 1/27;
            filename = strcat('NNM1_27mp');
        elseif n2 == 258
            q = 1/29;
            filename = strcat('NNM1_29mp');
        elseif n2 == 259
            q = 2/29;
            filename = strcat('NNM2_29mp');
        elseif n2 == 260
            q = 3/29;
            filename = strcat('NNM3_29mp');
        elseif n2 == 261
            q = 4/29;
            filename = strcat('NNM4_29mp');
        elseif n2 == 262
            q = 5/29;
            filename = strcat('NNM5_29mp');
        elseif n2 == 263
            q = 1/2-2/11;
            filename = strcat('NNM2_11pm');
        elseif n2 == 264
            q = 1/2-4/11;
            filename = strcat('NNM4_11pm');
        elseif n2 == 265
            q = 1/2-6/13;
            filename = strcat('NNM6_13pm');
        elseif n2 == 266
            q = 1/2-7/15;
            filename = strcat('NNM7_15pm');
        elseif n2 == 267
            q = 1/2-8/17;
            filename = strcat('NNM8_17pm');
        elseif n2 == 268
            q = 1/2-1/29;
            filename = strcat('NNM1_29pm');
        elseif n2 == 269
            q = 1/2-14/29;
            filename = strcat('NNM14_29pm');
        elseif n2 == 270
            q = 1/2-1/20;
            filename = strcat('NNM1_20mm');
        elseif n2 == 271
            q = 1/2-1/24;
            filename = strcat('NNM1_24mm');
        elseif n2 == 272
            q = 1/2-1/19;
            filename = strcat('NNM1_19mm');
        elseif n2 == 273
            q = 20/41;
            filename = strcat('NNM20_41mp');
        elseif n2 == 274
            q = 24/49;
            filename = strcat('NNM24_49mp');
        elseif n2 == 275
            q = 27/56;
            filename = strcat('NNM27_56mp');
        elseif n2 == 276
            q = 29/60;
            filename = strcat('NNM29_60mp');
        elseif n2 == 277
            q = 35/72;
            filename = strcat('NNM35_72mp');
        elseif n2 == 278
            q = 37/76;
            filename = strcat('NNM37_76mp');
        elseif n2 == 279
            q = 27/56;
            filename = strcat('NNM27_56pp');
        elseif n2 == 280
            q = 29/60;
            filename = strcat('NNM29_60pp');
        elseif n2 == 281
            q = 35/72;
            filename = strcat('NNM35_72pp');
        elseif n2 == 282
            q = 19/39;
            filename = strcat('NNM19_39pp');
        elseif n2 == 283
            q = 37/76;
            filename = strcat('NNM37_76pp');
        else
            % disp(n2);
            break
        end
        load(filename);
        label1 = size(NNM,1)/4;
        NNMtemp = NNM;
        
        Adiff = nan(2,1);
        for n1 = 1:size(NNMtemp,1)/4
            Adiff(n1) = abs(NNMtemp(4*(n1-1)+2,1)-A);
        end
        [minAdiff,minAdiffLabel] = min(Adiff);
        
        NNMAtemp = nan(1,11);
        
        if n3 == size(Asample,2)
            tola = tola2;
        else
            tola = tola1;
        end
        
        
        
        if minAdiff < tola2
            if q == 0 || q == 1/2
                flagRec = 1;
            elseif NNM(4*(minAdiffLabel-1)+2,3) < tolUp2
                flagRec = 1;
            else
                flagRec = 0;
            end
            
            if flagRec == 1
                n2RecLabel = n2RecLabel+1;
                n2Rec(n2RecLabel) = n2;
                % disp(n2);
                labelWN = labelWN+1;
                waveNumRec(labelWN,1) = n2;
                waveNumRec(labelWN,2) = NNM(4*(minAdiffLabel-1)+2,3);
                
                
                NNMAtemp(1,11) = minAdiff;
                NNMAtemp(1,1) = NNM(4*(minAdiffLabel-1)+2,1);
                NNMAtemp(1,2) = q;
                NNMAtemp(1,3) = NNM(4*(minAdiffLabel-1)+2,2);
                %             if abs(NNM(4*(minAdiffLabel-1)+2,2)-1.0557) < 2e-4
                %                 disp(n2);
                %             end
                if q ~= 1/2
                    NNMAtemp(1,4) = NNM(4*(minAdiffLabel-1)+3,1);
                    NNMAtemp(1,5:8) = NNM(4*(minAdiffLabel-1)+4,1:4);
                    NNMAtemp(1,9) = NNM(2,4);
                    NNMAtemp(1,10) = NNM(2,5);
                else
                    NNMAtemp(1,9) = sw;
                end
                
                %             NNMAtemp(2,:) = NNMAtemp(1,:);
                %             NNMAtemp(2,2) = 1-q;
                
                if ~isnan(NNMAtemp(1,1))
                    label = label+1;
                    NNMAtemp2(label,:) = NNMAtemp(1,:);
                    %                 label = label+1;
                    %                 NNMAtemp2(label,:) = NNMAtemp(2,:);
                    labelTot = labelTot+1;
                    NNMAtot(labelTot,:) = NNMAtemp(1,:);
                    %                 labelTot = labelTot+1;
                    %                 NNMAtot(labelTot,:) = NNMAtemp(2,:);
                else
                    disp(n2);
                end
            end
        else
            % disp(n2);
        end
    end
    
    NNMA = nan(size(NNMAtemp2,1),size(NNMAtemp2,2));
    [qsort,Isort] = sort(NNMAtemp2(:,2));
    for n1 = 1:size(NNMAtemp2,1)
        NNMA(n1,:) = NNMAtemp2(Isort(n1),:);
    end
    
    NNMA1 = nan(2,size(NNMA,2));
    NNMA2 = nan(2,size(NNMA,2));
    label1 = 0;
    label2 = 0;
    for n1 = 1:size(NNMA,1)
        if NNMA(n1,3) >= wc
            label1 = label1+1;
            NNMA1(label1,:) = NNMA(n1,:); % upper band
        else
            label2 = label2+1;
            NNMA2(label2,:) = NNMA(n1,:); % lower band
        end
    end
    
    figure(n3); clf;
    hold on;
    for n4 = 1:size(NNMA1,1)
        plot(NNMA1(n4,2),NNMA1(n4,3),'r.')
    end
    for n4 = 1:size(NNMA2,1)
        plot(NNMA2(n4,2),NNMA2(n4,3),'b.')
    end
    hold off;
    
end















% figure(1000); clf;
% hold on;
% for n4 = 1:size(NNMAtot,1)
%     if NNMAtot(n4,9) == 1
%         plot(NNMAtot(n4,2),NNMAtot(n4,3),'b.')
%     elseif NNMAtot(n4,9) == -1
%         plot(NNMAtot(n4,2),NNMAtot(n4,3),'r.')
%     end
% end
% hold off;


NNMAtotTemp1S = nan(1000,11,size(Asample,2));
NNMAtotTemp2S = nan(1000,11,size(Asample,2));
% NNMAtotTemp1SMir = nan(100,11,size(Asample,2));
% NNMAtotTemp2SMir = nan(100,11,size(Asample,2));

NNMAfit1 = nan(2,2,size(Asample,2));
NNMAfit2 = nan(2,2,size(Asample,2));
% NNMAfit1Mir = nan(2,2,size(Asample,2));
% NNMAfit2Mir = nan(2,2,size(Asample,2));

figure(1001); clf;
hold on;

e0 = 1.5; %1.5;
c1 = 0.25;
c2 = 0.37;
label = 0;
wLinear1 = zeros(2,2); % upper band
wLinear2 = zeros(2,2); % lower band
for qTemp = 0:dq2Pi:0.5
    label = label+1;
    wLinear1(label,1) = qTemp;
    wLinear1(label,2) = e0+sqrt(c1^2+c2^2+2*c1*c2*cos(qTemp*2*pi));
    wLinear2(label,1) = qTemp;
    wLinear2(label,2) = e0-sqrt(c1^2+c2^2+2*c1*c2*cos(qTemp*2*pi));
end

plot(wLinear1(:,1),wLinear1(:,2),'c-')
plot(wLinear2(:,1),wLinear2(:,2),'c-')

for n1 = 1:size(Asample,2)
    if n1 == size(Asample,2)
        tola = tola2;
    else
        tola = tola1;
    end
    A = Asample(n1);
    if ~isnan(A)
        NNMAtotTemp1 = nan(2,size(NNMAtot,2));
        NNMAtotTemp2 = nan(2,size(NNMAtot,2));
        label1 = 0;
        label2 = 0;
        for n4 = 1:size(NNMAtot,1)
            if abs(NNMAtot(n4,1)-A) < tola
                if NNMAtot(n4,3) >= wc
                    label1 = label1+1;
                    NNMAtotTemp1(label1,:) = NNMAtot(n4,:);
                elseif NNMAtot(n4,3) < wc
                    label2 = label2+1;
                    NNMAtotTemp2(label2,:) = NNMAtot(n4,:);
                end
            end
        end
        [NNMAtotSort1,I1] = sort(NNMAtotTemp1(:,2));
        [NNMAtotSort2,I2] = sort(NNMAtotTemp2(:,2));
        
        
        for n10 = 1:size(NNMAtotTemp1,1)
            NNMAtotTemp1S(n10,:,n1) = NNMAtotTemp1(I1(n10),:);
        end
        for n10 = 1:size(NNMAtotTemp2,1)
            NNMAtotTemp2S(n10,:,n1) = NNMAtotTemp2(I2(n10),:);
        end
        
        NNMlength1 = 0;
        for n10 = 1:size(NNMAtotTemp1S,1)
            if ~isnan(NNMAtotTemp1S(n10,1,n1))
                NNMlength1 = NNMlength1+1;
            end
        end
        % p1 = polyfit(NNMAtotTemp1S(1:NNMlength1,2,n1),NNMAtotTemp1S(1:NNMlength1,3,n1),polyOrder1);
        
        NNMlength2 = 0;
        for n10 = 1:size(NNMAtotTemp2S,1)
            if ~isnan(NNMAtotTemp2S(n10,1,n1))
                NNMlength2 = NNMlength2+1;
            end
        end
        % p2 = polyfit(NNMAtotTemp2S(1:NNMlength2,2,n1),NNMAtotTemp2S(1:NNMlength2,3,n1),polyOrder2);
        
        %         labelNNMfit = 0;
        %
        %         for qTemp = 0:dq2Pi:0.5
        %             labelNNMfit = labelNNMfit+1;
        %             NNMAfit1(labelNNMfit,1,n1) = qTemp;
        %             NNMAfit1(labelNNMfit,2,n1) = 0;
        %
        %             for n13 = 1:polyOrder1+1
        %                 NNMAfit1(labelNNMfit,2,n1) = NNMAfit1(labelNNMfit,2,n1)+p1(n13)*qTemp^(polyOrder1+1-n13);
        %             end
        %
        %             NNMAfit2(labelNNMfit,1,n1) = qTemp;
        %             NNMAfit2(labelNNMfit,2,n1) = 0;
        %
        %             for n13 = 1:polyOrder2+1
        %                 NNMAfit2(labelNNMfit,2,n1) = NNMAfit2(labelNNMfit,2,n1)+p2(n13)*qTemp^(polyOrder2+1-n13);
        %             end
        %         end
        
        %         plot(NNMAfit1(:,1,n1),NNMAfit1(:,2,n1),'b-','color',coloring(n1,:))
        %         plot(NNMAfit2(:,1,n1),NNMAfit2(:,2,n1),'r-','color',coloring(n1,:))
        
        plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','color',coloring(n1,:))
        plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.-','color',coloring(n1,:))
        
    end
    
    plot([0 0.5],[1.5 1.5],'k--')
end
hold off;





figure(1002); clf;
hold on;

n1 = 0;
H1 = plot([10 10],[0 10],'g-','linewidth',lineWidth*3,'markersize',markerSize*4,'color',colors(n1+1,:));
plot(wLinear1(:,1),wLinear1(:,2),'g-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
plot(wLinear2(:,1),wLinear2(:,2),'g-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(1-wLinear1(:,1),wLinear1(:,2),'g-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(1-wLinear2(:,1),wLinear2(:,2),'g-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
[maxQ,maxQlabel] = max(wLinear1(:,1));
plot(wLinear1(maxQlabel,1),wLinear1(maxQlabel,2),'^','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
[maxQ,maxQlabel] = max(wLinear2(:,1));
plot(wLinear2(maxQlabel,1),wLinear2(maxQlabel,2),'^','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));

n1 = 1;
NNMAtotTemp1S2 = nan(size(NNMAtotTemp1S,1),size(NNMAtotTemp1S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp1S(:,2,n1));
NNMAtotTemp1S2(1,1) = NNMAtotTemp1S(maxQlabel,2,n1);
NNMAtotTemp1S2(1,2) = NNMAtotTemp1S(maxQlabel,3,n1);
plot(NNMAtotTemp1S2(1,1),NNMAtotTemp1S2(1,2),'s','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp1S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp1S(ntemp11,2,n1)-NNMAtotTemp1S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
            NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
        NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(1,2,n1);
NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(1,3,n1);

NNMAtotTemp2S2 = nan(size(NNMAtotTemp2S,1),size(NNMAtotTemp2S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp2S(:,2,n1));
NNMAtotTemp2S2(1,1) = NNMAtotTemp2S(maxQlabel,2,n1);
NNMAtotTemp2S2(1,2) = NNMAtotTemp2S(maxQlabel,3,n1);
plot(NNMAtotTemp2S2(1,1),NNMAtotTemp2S2(1,2),'s','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp2S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp2S(ntemp11,2,n1)-NNMAtotTemp2S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
            NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
        NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(1,2,n1);
NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(1,3,n1);

H2 = plot([10 10],[0 10],'m.-','linewidth',lineWidth*3,'markersize',markerSize*4,'color',colors(n1+1,:));
plot(NNMAtotTemp1S2(:,1),NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
plot(NNMAtotTemp2S2(:,1),NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1S2(:,1),NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2S2(:,1),NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))

% n1 = 2;
% H3 = plot([10 10],[0 10],'b.-','linewidth',lineWidth*3,'markersize',markerSize*3,'color',colors(n1+1,:));
% plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
% plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
% plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))

n1 = 3;
NNMAtotTemp1S2 = nan(size(NNMAtotTemp1S,1),size(NNMAtotTemp1S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp1S(:,2,n1));
NNMAtotTemp1S2(1,1) = NNMAtotTemp1S(maxQlabel,2,n1);
NNMAtotTemp1S2(1,2) = NNMAtotTemp1S(maxQlabel,3,n1);
plot(NNMAtotTemp1S2(1,1),NNMAtotTemp1S2(1,2),'o','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp1S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp1S(ntemp11,2,n1)-NNMAtotTemp1S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
            NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
        NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(1,2,n1);
NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(1,3,n1);

NNMAtotTemp2S2 = nan(size(NNMAtotTemp2S,1),size(NNMAtotTemp2S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp2S(:,2,n1));
NNMAtotTemp2S2(1,1) = NNMAtotTemp2S(maxQlabel,2,n1);
NNMAtotTemp2S2(1,2) = NNMAtotTemp2S(maxQlabel,3,n1);
plot(NNMAtotTemp2S2(1,1),NNMAtotTemp2S2(1,2),'o','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp2S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp2S(ntemp11,2,n1)-NNMAtotTemp2S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
            NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
        NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(1,2,n1);
NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(1,3,n1);

H4 = plot([10 10],[0 10],'m.-','linewidth',lineWidth*3,'markersize',markerSize*4,'color',colors(n1+1,:));
plot(NNMAtotTemp1S2(:,1),NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
plot(NNMAtotTemp2S2(:,1),NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1S2(:,1),NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2S2(:,1),NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))

% n1 = 4;
% H5 = plot([10 10],[0 10],'k.-','linewidth',lineWidth*3,'markersize',markerSize*3,'color',colors(n1+1,:));
% plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
% plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
% plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))

n1 = 5;
NNMAtotTemp1S2 = nan(size(NNMAtotTemp1S,1),size(NNMAtotTemp1S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp1S(:,2,n1));
NNMAtotTemp1S2(1,1) = NNMAtotTemp1S(maxQlabel,2,n1);
NNMAtotTemp1S2(1,2) = NNMAtotTemp1S(maxQlabel,3,n1);
plot(NNMAtotTemp1S2(1,1),NNMAtotTemp1S2(1,2),'v','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp1S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp1S(ntemp11,2,n1)-NNMAtotTemp1S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
            NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
        NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(1,2,n1);
NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(1,3,n1);

NNMAtotTemp2S2 = nan(size(NNMAtotTemp2S,1),size(NNMAtotTemp2S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp2S(:,2,n1));
NNMAtotTemp2S2(1,1) = NNMAtotTemp2S(maxQlabel,2,n1);
NNMAtotTemp2S2(1,2) = NNMAtotTemp2S(maxQlabel,3,n1);
plot(NNMAtotTemp2S2(1,1),NNMAtotTemp2S2(1,2),'v','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp2S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp2S(ntemp11,2,n1)-NNMAtotTemp2S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
            NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
        NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(1,2,n1);
NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(1,3,n1);

H6 = plot([10 10],[0 10],'m.-','linewidth',lineWidth*3,'markersize',markerSize*4,'color',colors(n1+1,:));
plot(NNMAtotTemp1S2(:,1),NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
plot(NNMAtotTemp2S2(:,1),NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1S2(:,1),NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2S2(:,1),NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))

plot([0 1],[1.5 1.5],'k--','linewidth',lineWidth*1.5)

% plot([x1 x2],[y1 y1],'k-','linewidth',lineWidth)
% plot([x1 x1],[y1 y2],'k-','linewidth',lineWidth)
% plot([x1 x2],[y2 y2],'k-','linewidth',lineWidth)
% plot([x2 x2],[y1 y2],'k-','linewidth',lineWidth)

axis([0 1 fig1002Y1 fig1002Y2])
hold off;
xticks([0 0.5 1])
xticklabels({'0','\pi','2\pi'})
yticks([0.5 1 1.5 2 2.5])
legend([H1 H2 H4 H6],{'$A=0$','$A=0.4$','$A=A_c$','$A=1.1$'},'Location','north','FontSize',10,'Interpreter','latex');
% legend([H1 H2 H3 H4 H5 H6],{'$A=0$','$A=0.4$','$A=0.8$','$A=A_c$','$A=1$','$A=1.1$'},'Location','east','FontSize',15.5,'Interpreter','latex');
% set(gca, 'YScale', 'log')
set(gca,'linewidth',2)
set(gca,'FontSize',19)
xlabel('$q$','Interpreter','latex')
ylabel('$\omega$','Interpreter','latex')
%axis square












figure(1102); clf;
hold on;

n1 = 0;
H1 = plot([10 10],[0 10],'g-','linewidth',lineWidth*3,'markersize',markerSize*3,'color',colors(n1+1,:));
plot(wLinear1(:,1)+0.5,wLinear1(:,2),'g-','linewidth',lineWidth*1.5,'markersize',markerSize,'color',colors(n1+1,:));
plot(wLinear2(:,1)+0.5,wLinear2(:,2),'g-','linewidth',lineWidth*1.5,'markersize',markerSize,'color',colors(n1+1,:))
plot(0.5-wLinear1(:,1),wLinear1(:,2),'g-','linewidth',lineWidth*1.5,'markersize',markerSize,'color',colors(n1+1,:))
plot(0.5-wLinear2(:,1),wLinear2(:,2),'g-','linewidth',lineWidth*1.5,'markersize',markerSize,'color',colors(n1+1,:))
[maxQ,maxQlabel] = max(wLinear1(:,1));
plot(wLinear1(maxQlabel,1)+0.5,wLinear1(maxQlabel,2),'^','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
[maxQ,maxQlabel] = max(wLinear2(:,1));
plot(wLinear2(maxQlabel,1)+0.5,wLinear2(maxQlabel,2),'^','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));

n1 = 1;
NNMAtotTemp1S2 = nan(size(NNMAtotTemp1S,1),size(NNMAtotTemp1S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp1S(:,2,n1));
NNMAtotTemp1S2(1,1) = NNMAtotTemp1S(maxQlabel,2,n1);
NNMAtotTemp1S2(1,2) = NNMAtotTemp1S(maxQlabel,3,n1);
plot(NNMAtotTemp1S2(1,1)+0.5,NNMAtotTemp1S2(1,2),'s','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp1S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp1S(ntemp11,2,n1)-NNMAtotTemp1S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
            NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
        NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(1,2,n1);
NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(1,3,n1);

NNMAtotTemp2S2 = nan(size(NNMAtotTemp2S,1),size(NNMAtotTemp2S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp2S(:,2,n1));
NNMAtotTemp2S2(1,1) = NNMAtotTemp2S(maxQlabel,2,n1);
NNMAtotTemp2S2(1,2) = NNMAtotTemp2S(maxQlabel,3,n1);
plot(NNMAtotTemp2S2(1,1)+0.5,NNMAtotTemp2S2(1,2),'s','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp2S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp2S(ntemp11,2,n1)-NNMAtotTemp2S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
            NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
        NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(1,2,n1);
NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(1,3,n1);

H2 = plot([10 10],[0 10],'m.-','linewidth',lineWidth*3,'markersize',markerSize*3,'color',colors(n1+1,:));
plot(NNMAtotTemp1S2(:,1)+0.5,NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
plot(NNMAtotTemp2S2(:,1)+0.5,NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(0.5-NNMAtotTemp1S2(:,1),NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(0.5-NNMAtotTemp2S2(:,1),NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))

% n1 = 2;
% H3 = plot([10 10],[0 10],'b.-','linewidth',lineWidth*3,'markersize',markerSize*3,'color',colors(n1+1,:));
% plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
% plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
% plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))

n1 = 3;
NNMAtotTemp1S2 = nan(size(NNMAtotTemp1S,1),size(NNMAtotTemp1S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp1S(:,2,n1));
NNMAtotTemp1S2(1,1) = NNMAtotTemp1S(maxQlabel,2,n1);
NNMAtotTemp1S2(1,2) = NNMAtotTemp1S(maxQlabel,3,n1);
plot(NNMAtotTemp1S2(1,1)+0.5,NNMAtotTemp1S2(1,2),'o','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp1S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp1S(ntemp11,2,n1)-NNMAtotTemp1S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
            NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
        NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(1,2,n1);
NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(1,3,n1);

NNMAtotTemp2S2 = nan(size(NNMAtotTemp2S,1),size(NNMAtotTemp2S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp2S(:,2,n1));
NNMAtotTemp2S2(1,1) = NNMAtotTemp2S(maxQlabel,2,n1);
NNMAtotTemp2S2(1,2) = NNMAtotTemp2S(maxQlabel,3,n1);
plot(NNMAtotTemp2S2(1,1)+0.5,NNMAtotTemp2S2(1,2),'o','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp2S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp2S(ntemp11,2,n1)-NNMAtotTemp2S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
            NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
        NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(1,2,n1);
NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(1,3,n1);

H4 = plot([10 10],[0 10],'m.-','linewidth',lineWidth*3,'markersize',markerSize*3,'color',colors(n1+1,:));
plot(NNMAtotTemp1S2(:,1)+0.5,NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
plot(NNMAtotTemp2S2(:,1)+0.5,NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(0.5-NNMAtotTemp1S2(:,1),NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(0.5-NNMAtotTemp2S2(:,1),NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))

% n1 = 4;
% H5 = plot([10 10],[0 10],'k.-','linewidth',lineWidth*3,'markersize',markerSize*3,'color',colors(n1+1,:));
% plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
% plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
% plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))

n1 = 5;
NNMAtotTemp1S2 = nan(size(NNMAtotTemp1S,1),size(NNMAtotTemp1S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp1S(:,2,n1));
NNMAtotTemp1S2(1,1) = NNMAtotTemp1S(maxQlabel,2,n1);
NNMAtotTemp1S2(1,2) = NNMAtotTemp1S(maxQlabel,3,n1);
plot(NNMAtotTemp1S2(1,1)+0.5,NNMAtotTemp1S2(1,2),'v','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp1S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp1S(ntemp11,2,n1)-NNMAtotTemp1S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
            NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(ntemp11,2,n1);
        NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp1S2(labelTemp1,1) = NNMAtotTemp1S(1,2,n1);
NNMAtotTemp1S2(labelTemp1,2) = NNMAtotTemp1S(1,3,n1);

NNMAtotTemp2S2 = nan(size(NNMAtotTemp2S,1),size(NNMAtotTemp2S,2));
[maxQ,maxQlabel] = max(NNMAtotTemp2S(:,2,n1));
NNMAtotTemp2S2(1,1) = NNMAtotTemp2S(maxQlabel,2,n1);
NNMAtotTemp2S2(1,2) = NNMAtotTemp2S(maxQlabel,3,n1);
plot(NNMAtotTemp2S2(1,1)+0.5,NNMAtotTemp2S2(1,2),'v','markersize',markerSize3/sFac/2.5,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
labelTemp1 = 1;
for ntemp11 = size(NNMAtotTemp2S,1):-1:1
    if Qgap == 1
        if NNMAtotTemp2S(ntemp11,2,n1)-NNMAtotTemp2S2(labelTemp1,1) < -deltaQ
            labelTemp1 = labelTemp1+1;
            NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
            NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
        end
    else
        labelTemp1 = labelTemp1+1;
        NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(ntemp11,2,n1);
        NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(ntemp11,3,n1);
    end
end
labelTemp1 = labelTemp1+1;
NNMAtotTemp2S2(labelTemp1,1) = NNMAtotTemp2S(1,2,n1);
NNMAtotTemp2S2(labelTemp1,2) = NNMAtotTemp2S(1,3,n1);

H6 = plot([10 10],[0 10],'m.-','linewidth',lineWidth*3,'markersize',markerSize*3,'color',colors(n1+1,:));
plot(NNMAtotTemp1S2(:,1)+0.5,NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:));
plot(NNMAtotTemp2S2(:,1)+0.5,NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(0.5-NNMAtotTemp1S2(:,1),NNMAtotTemp1S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))
plot(0.5-NNMAtotTemp2S2(:,1),NNMAtotTemp2S2(:,2),'m.-','linewidth',lineWidth,'markersize',markerSize,'color',colors(n1+1,:))

%plot([0 1],[1.5 1.5],'k--','linewidth',lineWidth*1.5)

% plot([x1 x2],[y1 y1],'k-','linewidth',lineWidth)
% plot([x1 x1],[y1 y2],'k-','linewidth',lineWidth)
% plot([x1 x2],[y2 y2],'k-','linewidth',lineWidth)
% plot([x2 x2],[y1 y2],'k-','linewidth',lineWidth)

axis([0 1 fig1002Y1 fig1002Y2])
hold off;
xticks([0 0.5 1])
xticklabels({'-\pi','0','\pi'})
yticks([0.5 1 1.5 2 2.5])
legend([H1 H2 H4 H6],{'$A=0$','$A=0.4$','$A=A_c$','$A=1.1$'},'Location','north','FontSize',10,'Interpreter','latex');
% legend([H1 H2 H3 H4 H5 H6],{'$A=0$','$A=0.4$','$A=0.8$','$A=A_c$','$A=1$','$A=1.1$'},'Location','east','FontSize',15.5,'Interpreter','latex');
% set(gca, 'YScale', 'log')
set(gca,'linewidth',2)
set(gca,'FontSize',19)
xlabel('$q$','Interpreter','latex')
ylabel('$\omega$','Interpreter','latex')
%axis square










figure(1005); clf;
hold on;



n1 = 0;
plot(wLinear1(:,1),wLinear1(:,2),'g-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:));
plot(wLinear2(:,1),wLinear2(:,2),'g-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-wLinear1(:,1),wLinear1(:,2),'g-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-wLinear2(:,1),wLinear2(:,2),'g-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
wLinearTemp1 = wLinear1;
wLinearTemp2 = wLinear2;
for n = 1:size(wLinearTemp1,1)
    if abs(wLinearTemp1(n,1)-0.5) < 1e-6
        plot(wLinearTemp1(n,1),wLinearTemp1(n,2),'v','markersize',markerSize3/sFac,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
        wLinearTemp1(n,1) = nan;
        wLinearTemp1(n,2) = nan;
        break
    end
end
for n = 1:size(wLinearTemp2,1)
    if abs(wLinearTemp2(n,1)-0.5) < 1e-6
        plot(wLinearTemp2(n,1),wLinearTemp2(n,2),'^','markersize',markerSize3/sFac,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:))
        wLinearTemp2(n,1) = nan;
        wLinearTemp2(n,2) = nan;
        break
    end
end
plot(wLinearTemp1(:,1),wLinearTemp1(:,2),'g-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:));
plot(wLinearTemp2(:,1),wLinear2(:,2),'g-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-wLinearTemp1(:,1),wLinearTemp1(:,2),'g-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-wLinearTemp2(:,1),wLinearTemp2(:,2),'g-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))





NNMAtotTemp1tempS = NNMAtotTemp1S;
NNMAtotTemp2tempS = NNMAtotTemp2S;

n1 = 1;
plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:));
plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
for n = 1:size(NNMAtotTemp1tempS,1)
    if abs(NNMAtotTemp1tempS(n,2,n1)-0.5) < 1e-6
        plot(NNMAtotTemp1tempS(n,2,n1),NNMAtotTemp1tempS(n,3,n1),'v','markersize',markerSize3/sFac,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:))
        NNMAtotTemp1tempS(n,2,n1) = nan;
        NNMAtotTemp1tempS(n,3,n1) = nan;
        break
    end
end
for n = 1:size(NNMAtotTemp2tempS,1)
    if abs(NNMAtotTemp2tempS(n,2,n1)-0.5) < 1e-6
        plot(NNMAtotTemp2tempS(n,2,n1),NNMAtotTemp2tempS(n,3,n1),'^','markersize',markerSize3/sFac,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:))
        NNMAtotTemp2tempS(n,2,n1) = nan;
        NNMAtotTemp2tempS(n,3,n1) = nan;
        break
    end
end
plot(NNMAtotTemp1tempS(:,2,n1),NNMAtotTemp1tempS(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:));
plot(NNMAtotTemp2tempS(:,2,n1),NNMAtotTemp2tempS(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1tempS(:,2,n1),NNMAtotTemp1tempS(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2tempS(:,2,n1),NNMAtotTemp2tempS(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))






n1 = 2;
plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:));
plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
for n = 1:size(NNMAtotTemp1tempS,1)
    if abs(NNMAtotTemp1tempS(n,2,n1)-0.5) < 1e-6
        H1 = plot(NNMAtotTemp1tempS(n,2,n1),NNMAtotTemp1tempS(n,3,n1),'v','markersize',markerSize3/sFac,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
        NNMAtotTemp1tempS(n,2,n1) = nan;
        NNMAtotTemp1tempS(n,3,n1) = nan;
        break
    end
end
for n = 1:size(NNMAtotTemp2tempS,1)
    if abs(NNMAtotTemp2tempS(n,2,n1)-0.5) < 1e-6
        H2 = plot(NNMAtotTemp2tempS(n,2,n1),NNMAtotTemp2tempS(n,3,n1),'^','markersize',markerSize3/sFac,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
        NNMAtotTemp2tempS(n,2,n1) = nan;
        NNMAtotTemp2tempS(n,3,n1) = nan;
        break
    end
end
plot(NNMAtotTemp1tempS(:,2,n1),NNMAtotTemp1tempS(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:));
plot(NNMAtotTemp2tempS(:,2,n1),NNMAtotTemp2tempS(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1tempS(:,2,n1),NNMAtotTemp1tempS(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2tempS(:,2,n1),NNMAtotTemp2tempS(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))







n1 = 3;
plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:));
plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
for n = 1:size(NNMAtotTemp1tempS,1)
    if abs(NNMAtotTemp1tempS(n,2,n1)-0.5) < 1e-6
        % plot symmetric and anti-symmetric together
        plot(NNMAtotTemp1tempS(n,2,n1),NNMAtotTemp1tempS(n,3,n1),'v','markersize',markerSize3/sFac,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
        plot(NNMAtotTemp1tempS(n,2,n1),NNMAtotTemp1tempS(n,3,n1),'^','markersize',markerSize3/sFac2,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:));
        NNMAtotTemp1tempS(n,2,n1) = nan;
        NNMAtotTemp1tempS(n,3,n1) = nan;
        break
    end
end
for n = 1:size(NNMAtotTemp2tempS,1)
    if abs(NNMAtotTemp2tempS(n,2,n1)-0.5) < 1e-6
        plot(NNMAtotTemp2tempS(n,2,n1),NNMAtotTemp2tempS(n,3,n1),'v','markersize',markerSize3/sFac,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:))
        plot(NNMAtotTemp2tempS(n,2,n1),NNMAtotTemp2tempS(n,3,n1),'^','markersize',markerSize3/sFac2,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:))
        NNMAtotTemp2tempS(n,2,n1) = nan;
        NNMAtotTemp2tempS(n,3,n1) = nan;
        break
    end
end
plot(NNMAtotTemp1tempS(:,2,n1),NNMAtotTemp1tempS(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:));
plot(NNMAtotTemp2tempS(:,2,n1),NNMAtotTemp2tempS(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1tempS(:,2,n1),NNMAtotTemp1tempS(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2tempS(:,2,n1),NNMAtotTemp2tempS(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))






n1 = 4;
plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:));
plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
for n = 1:size(NNMAtotTemp1tempS,1)
    if abs(NNMAtotTemp1tempS(n,2,n1)-0.5) < 1e-6
        plot(NNMAtotTemp1tempS(n,2,n1),NNMAtotTemp1tempS(n,3,n1),'^','markersize',markerSize3/sFac2,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:))
        NNMAtotTemp1tempS(n,2,n1) = nan;
        NNMAtotTemp1tempS(n,3,n1) = nan;
        break
    end
end
for n = 1:size(NNMAtotTemp2tempS,1)
    if abs(NNMAtotTemp2tempS(n,2,n1)-0.5) < 1e-6
        plot(NNMAtotTemp2tempS(n,2,n1),NNMAtotTemp2tempS(n,3,n1),'v','markersize',markerSize3/sFac2,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:))
        NNMAtotTemp2tempS(n,2,n1) = nan;
        NNMAtotTemp2tempS(n,3,n1) = nan;
        break
    end
end
plot(NNMAtotTemp1tempS(:,2,n1),NNMAtotTemp1tempS(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:));
plot(NNMAtotTemp2tempS(:,2,n1),NNMAtotTemp2tempS(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1tempS(:,2,n1),NNMAtotTemp1tempS(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2tempS(:,2,n1),NNMAtotTemp2tempS(:,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))






n1 = 5;
plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:));
plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize2/100,'color',colors(n1+1,:))
for n = 1:size(NNMAtotTemp1tempS,1)
    if abs(NNMAtotTemp1tempS(n,2,n1)-0.5) < 1e-6
        plot(NNMAtotTemp1tempS(n,2,n1),NNMAtotTemp1tempS(n,3,n1),'^','markersize',markerSize3/sFac2,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:))
        NNMAtotTemp1tempS(n,2,n1) = nan;
        NNMAtotTemp1tempS(n,3,n1) = nan;
        break
    end
end
for n = 1:size(NNMAtotTemp2tempS,1)
    if abs(NNMAtotTemp2tempS(n,2,n1)-0.5) < 1e-6
        plot(NNMAtotTemp2tempS(n,2,n1),NNMAtotTemp2tempS(n,3,n1),'v','markersize',markerSize3/sFac2,'Color',colors(n1+1,:),'MarkerFaceColor',colors(n1+1,:))
        NNMAtotTemp2tempS(n,2,n1) = nan;
        NNMAtotTemp2tempS(n,3,n1) = nan;
        break
    end
end
plot(NNMAtotTemp1tempS(:,2,n1),NNMAtotTemp1tempS(:,3,n1),'c.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:));
plot(NNMAtotTemp2tempS(:,2,n1),NNMAtotTemp2tempS(:,3,n1),'c.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-NNMAtotTemp1tempS(:,2,n1),NNMAtotTemp1tempS(:,3,n1),'c.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))
plot(1-NNMAtotTemp2tempS(:,2,n1),NNMAtotTemp2tempS(:,3,n1),'c.-','linewidth',lineWidth,'markersize',markerSize2,'color',colors(n1+1,:))



plot([0 1],[1.5 1.5],'k--','linewidth',lineWidth*2)


axis([x1 x2 y1 y2])
hold off;
xticks([0.45 0.5 0.55])
xticklabels({'0.9\pi','\pi','1.1\pi'})
yticks([1.4 1.5 1.6])
legend([H1 H2],{'$\phi_\pi=\pi$','$\phi_\pi=0$'},'Location','east','FontSize',16,'Interpreter','latex');
% legend([H1 H2 H3 H4 H5 H6],{'$A=0$','$A=0.4$','$A=0.8$','$A=A_c$','$A=1$','$A=1.1$'},'Location','south','FontSize',16,'Interpreter','latex');
% set(gca, 'YScale', 'log')
set(gca,'linewidth',2)
set(gca,'FontSize',19)
xlabel('$q$','Interpreter','latex')
ylabel('$\omega$','Interpreter','latex')









% figure(1003); clf;
% hold on;
%
% % n1 = 2;
% % H1 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize);
% % plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% % plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% % plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% %
% % n1 = 3;
% % H2 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize);
% % plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
% % plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
% % plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
%
% plot([0 1],[1.5 1.5],'k--','linewidth',lineWidth)
% axis([0 1 0.5 2.3])
% hold off;
% xticks([0 0.5 1])
% yticks([0.5 1 1.5 2])
% legend([H1 H2],{'$A=0.85$','$A=A_c$'},'Location','south','FontSize',16,'Interpreter','latex');
% % set(gca, 'YScale', 'log')
% set(gca,'linewidth',2)
% set(gca,'FontSize',19)
% xlabel('$q$','Interpreter','latex')
% ylabel('$\omega$','Interpreter','latex')









% figure(1004); clf;
% hold on;
%
% n1 = 4;
% H1 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize);
% plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
%
% n1 = 5;
% H2 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize);
% plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
%
% plot([0 1],[1.5 1.5],'k--','linewidth',lineWidth)
% axis([0 1 0.5 2.4])
% hold off;
% xticks([0 0.5 1])
% yticks([0.5 1 1.5 2])
% legend([H1 H2],{'$A=1$','$A=1.1$'},'Location','south','FontSize',16,'Interpreter','latex');
% % set(gca, 'YScale', 'log')
% set(gca,'linewidth',2)
% set(gca,'FontSize',19)
% xlabel('$q$','Interpreter','latex')
% ylabel('$\omega$','Interpreter','latex')