% sorts data from A small to large and save it
filename1 = strcat('NNM65_131pp');

load(filename1);

NNMtemp = NNM;

ASortTemp = nan(size(NNM,1)/4,1);
for n1 = 1:size(NNM,1)/4
    ASortTemp(n1) = NNM(4*(n1-1)+2,1);
end
[ASort,ASortOrder] = sort(ASortTemp);
for n1 = 1:size(NNM,1)/4
    NNM(4*(n1-1)+1,:) = NNMtemp(4*(ASortOrder(n1)-1)+1,:);
    NNM(4*(n1-1)+2,:) = NNMtemp(4*(ASortOrder(n1)-1)+2,:);
    NNM(4*(n1-1)+3,:) = NNMtemp(4*(ASortOrder(n1)-1)+3,:);
    NNM(4*(n1-1)+4,:) = NNMtemp(4*(ASortOrder(n1)-1)+4,:);
end

save(filename1,'NNM');