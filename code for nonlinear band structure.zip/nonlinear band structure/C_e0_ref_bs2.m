Ac = 0.774596669241483;
wc = 0;
tolUp2 = 1e10; % 3e-3;

lineWidth = 1;
markerSize = 12;

tolA1 = 3e-3;
tolA2 = 2e-2;
e0 = 0;
dq2Pi = 0.5/200; % wave number in units of 2pi   0.5 corresponds to pi

sw = -1;

pmmmSswitch = 1;
NNMAtot = nan(30,11); % 1:A, 2:q, 3:w, 4:InterPhase, 5,6,7,8:IntraPhase, 9,10:pp,pm,mp,mm
labelTot = 0;

Asample = [0.2*Ac 0.5*Ac]; 

coloring = nan(size(Asample,2),3);
coloring(1,:) = [0 1 1];
coloring(2,:) = [1 0 1];
coloring(3,:) = [0 0 0];
coloring(4,:) = [0 0 1];
coloring(5,:) = [1 0 0];
coloring(6,:) = [1 0.6 0];

for n3 = 1:size(Asample,2)
    
    waveNumRec = zeros(2,2);
    labelWN = 0;
    
    n2Rec = nan(500,1);
    n2RecLabel = 0;
    
    NNMAtemp2 = nan(30,11); % 1:A, 2:q, 3:w, 4:InterPhase, 5,6,7,8:IntraPhase, 9,10:pp,pm,mp,mm
    A = Asample(n3);
    tola1 = A*tolA1;
    tola2 = A*tolA2;
    
    label = 0;
    label1 = 0;
    label2 = 0;
    % filename1 = strcat('.\Kagome_lattice\Kagome_Diode\Kagome_diode_fine_in_0_125_',num2str(i));
    % n2 = 0;
    for n2 = 1:1000
        if n2 == 1
            q = 1/3;
            filename = strcat('NNMe0_1_3pp');
        elseif n2 == 2
            q = 1/5;
            filename = strcat('NNMe0_1_5pp');
        elseif n2 == 3
            q = 2/5;
            filename = strcat('NNMe0_2_5pp');
        elseif n2 == 4
            q = 1/7;
            filename = strcat('NNMe0_1_7pp');
        elseif n2 == 5
            q = 2/7;
            filename = strcat('NNMe0_2_7pp');
        elseif n2 == 6
            q = 3/7;
            filename = strcat('NNMe0_3_7pp');
        elseif n2 == 7 
            q = 4/13;
            filename = strcat('NNMe0_4_13pp');
        elseif n2 == 8 
            q = 1/9;
            filename = strcat('NNMe0_1_9pp');
        elseif n2 == 9 
            q = 2/9;
            filename = strcat('NNMe0_2_9pp');
        elseif n2 == 10 
            q = 4/9;
            filename = strcat('NNMe0_4_9pp');
        elseif n2 == 11 
            q = 15/31;
            filename = strcat('NNMe0_15_31pp');
        elseif n2 == 12 
            q = 2/11;
            filename = strcat('NNMe0_2_11pp');
        elseif n2 == 13
            q = 3/11;
            filename = strcat('NNMe0_3_11pp');
        elseif n2 == 14
            q = 4/11;
            filename = strcat('NNMe0_4_11pp');
        elseif n2 == 15
            q = 5/11;
            filename = strcat('NNMe0_5_11pp');
        elseif n2 == 16 
            q = 1/11;
            filename = strcat('NNMe0_1_11pp');
        elseif n2 == 17 
            q = 1/13;
            filename = strcat('NNMe0_1_13pp');
        elseif n2 == 18 
            q = 3/13;
            filename = strcat('NNMe0_3_13pp');
        elseif n2 == 19
            q = 1/2;
            filename = strcat('NNMe0_1_2pp');
        elseif n2 == 20
            q = 0;
            filename = strcat('NNMe0_0pp');
        elseif n2 == 21 
            q = 5/13;
            filename = strcat('NNMe0_5_13pp');
        elseif n2 == 22 
            q = 6/13;
            filename = strcat('NNMe0_6_13pp');
        elseif n2 == 23
            q = 1/4;
            filename = strcat('NNMe0_1_4pp');
        elseif n2 == 24
            q = 1/8;
            filename = strcat('NNMe0_1_8pp');
        elseif n2 == 25
            q = 1/12;
            filename = strcat('NNMe0_1_12pp');
        elseif n2 == 26
            q = 1/15;
            filename = strcat('NNMe0_1_15pp');
        elseif n2 == 27
            q = 1/16;
            filename = strcat('NNMe0_1_16pp');
        elseif n2 == 28
            q = 3/16;
            filename = strcat('NNMe0_3_16pp');
        elseif n2 == 29
            q = 1/17;
            filename = strcat('NNMe0_1_17pp');
        elseif n2 == 30
            q = 2/17;
            filename = strcat('NNMe0_2_17pp');
        elseif n2 == 31
            q = 3/17;
            filename = strcat('NNMe0_3_17pp');
        elseif n2 == 32
            q = 4/17;
            filename = strcat('NNMe0_4_17pp');
        elseif n2 == 33
            q = 5/17;
            filename = strcat('NNMe0_5_17pp');
        elseif n2 == 34
            q = 6/17;
            filename = strcat('NNMe0_6_17pp');
        elseif n2 == 35
            q = 7/17;
            filename = strcat('NNMe0_7_17pp');
        elseif n2 == 36
            q = 8/17;
            filename = strcat('NNMe0_8_17pp');
        elseif n2 == 37
            q = 1/19;
            filename = strcat('NNMe0_1_19pp');
        elseif n2 == 38
            q = 2/19;
            filename = strcat('NNMe0_2_19pp');
        elseif n2 == 39
            q = 3/19;
            filename = strcat('NNMe0_3_19pp');
        elseif n2 == 40
            q = 4/19;
            filename = strcat('NNMe0_4_19pp');
        elseif n2 == 41
            q = 5/19;
            filename = strcat('NNMe0_5_19pp');
        elseif n2 == 42
            q = 6/19;
            filename = strcat('NNMe0_6_19pp');
        elseif n2 == 43
            q = 7/19;
            filename = strcat('NNMe0_7_19pp');
        elseif n2 == 44
            q = 8/19;
            filename = strcat('NNMe0_8_19pp');
        elseif n2 == 45
            q = 9/19;
            filename = strcat('NNMe0_9_19pp');
        elseif n2 == 46
            q = 2/13;
            filename = strcat('NNMe0_2_13pp');
        elseif n2 == 47
            q = 1/20;
            filename = strcat('NNMe0_1_20pp');
        elseif n2 == 48
            q = 3/20;
            filename = strcat('NNMe0_3_20pp');
        elseif n2 == 49
            q = 1/21;
            filename = strcat('NNMe0_1_21pp');
        elseif n2 == 50
            q = 2/21;
            filename = strcat('NNMe0_2_21pp');
        elseif n2 == 51
            q = 4/21;
            filename = strcat('NNMe0_4_21pp');
        elseif n2 == 52
            q = 5/21;
            filename = strcat('NNMe0_5_21pp');
        elseif n2 == 53
            q = 8/21;
            filename = strcat('NNMe0_8_21pp');
        elseif n2 == 54
            q = 10/21;
            filename = strcat('NNMe0_10_21pp');
        elseif n2 == 55
            q = 1/23;
            filename = strcat('NNMe0_1_23pp');
        elseif n2 == 56
            q = 2/23;
            filename = strcat('NNMe0_2_23pp');
        elseif n2 == 57
            q = 3/23;
            filename = strcat('NNMe0_3_23pp');
        elseif n2 == 58
            q = 4/23;
            filename = strcat('NNMe0_4_23pp');
        elseif n2 == 59
            q = 5/23;
            filename = strcat('NNMe0_5_23pp');
        elseif n2 == 60
            q = 6/23;
            filename = strcat('NNMe0_6_23pp');
        elseif n2 == 61
            q = 7/23;
            filename = strcat('NNMe0_7_23pp');
        elseif n2 == 62 
            q = 8/23;
            filename = strcat('NNMe0_8_23pp');
        elseif n2 == 63
            q = 9/23;
            filename = strcat('NNMe0_9_23pp');
        elseif n2 == 64
            q = 10/23;
            filename = strcat('NNMe0_10_23pp');
        elseif n2 == 65
            q = 11/23;
            filename = strcat('NNMe0_11_23pp');
        elseif n2 == 66
            q = 1/24;
            filename = strcat('NNMe0_1_24pp');
        elseif n2 == 67
            q = 5/24;
            filename = strcat('NNMe0_5_24pp');
        elseif n2 == 68
            q = 1/25;
            filename = strcat('NNMe0_1_25pp');
        elseif n2 == 69
            q = 2/25;
            filename = strcat('NNMe0_2_25pp');
        elseif n2 == 70
            q = 3/25;
            filename = strcat('NNMe0_3_25pp');
        elseif n2 == 71
            q = 4/25;
            filename = strcat('NNMe0_4_25pp');
        elseif n2 == 72
            q = 6/25;
            filename = strcat('NNMe0_6_25pp');
        elseif n2 == 73
            q = 7/25;
            filename = strcat('NNMe0_7_25pp');
        elseif n2 == 74
            q = 8/25;
            filename = strcat('NNMe0_8_25pp');
        elseif n2 == 75
            q = 9/25;
            filename = strcat('NNMe0_9_25pp');
        elseif n2 == 76
            q = 11/25;
            filename = strcat('NNMe0_11_25pp');
        elseif n2 == 77
            q = 12/25;
            filename = strcat('NNMe0_12_25pp');
        elseif n2 == 78
            q = 1/26;
            filename = strcat('NNMe0_1_26pp');
        elseif n2 == 79
            q = 3/26;
            filename = strcat('NNMe0_3_26pp');
        elseif n2 == 80
            q = 5/26;
            filename = strcat('NNMe0_5_26pp');
        elseif n2 == 81
            q = 7/26;
            filename = strcat('NNMe0_7_26pp');
        elseif n2 == 82
            q = 1/27;
            filename = strcat('NNMe0_1_27pp');
        elseif n2 == 83
            q = 2/27;
            filename = strcat('NNMe0_2_27pp');
        elseif n2 == 84
            q = 4/27;
            filename = strcat('NNMe0_4_27pp');
        elseif n2 == 85
            q = 5/27;
            filename = strcat('NNMe0_5_27pp');
        elseif n2 == 86
            q = 7/27;
            filename = strcat('NNMe0_7_27pp');
        elseif n2 == 87
            q = 8/27;
            filename = strcat('NNMe0_8_27pp');
        elseif n2 == 88
            q = 10/27;
            filename = strcat('NNMe0_10_27pp');
        elseif n2 == 89
            q = 11/27;
            filename = strcat('NNMe0_11_27pp');
        elseif n2 == 90
%             q = 12/27;
%             filename = strcat('NNMe0_12_27pp');
        elseif n2 == 91
            q = 13/27;
            filename = strcat('NNMe0_13_27pp');
        elseif n2 == 92 
            q = 1/28;
            filename = strcat('NNMe0_1_28pp');
        elseif n2 == 93 
            q = 3/28;
            filename = strcat('NNMe0_3_28pp');
        elseif n2 == 94
            q = 5/28;
            filename = strcat('NNMe0_5_28pp');
        elseif n2 == 95
            q = 9/28;
            filename = strcat('NNMe0_9_28pp');
        elseif n2 == 96
            q = 11/28;
            filename = strcat('NNMe0_11_28pp');
        elseif n2 == 97
            q = 13/28;
            filename = strcat('NNMe0_13_28pp');
        elseif n2 == 98
            q = 1/29;
            filename = strcat('NNMe0_1_29pp');
        elseif n2 == 99
            q = 2/29;
            filename = strcat('NNMe0_2_29pp');
        elseif n2 == 100
            q = 3/29;
            filename = strcat('NNMe0_3_29pp');
        elseif n2 == 101
            q = 4/29;
            filename = strcat('NNMe0_4_29pp');
        elseif n2 == 102
            q = 5/29;
            filename = strcat('NNMe0_5_29pp');
        elseif n2 == 103
            q = 6/29;
            filename = strcat('NNMe0_6_29pp');
        elseif n2 == 104
            q = 7/29;
            filename = strcat('NNMe0_7_29pp');
        elseif n2 == 105
            q = 8/29;
            filename = strcat('NNMe0_8_29pp');
        elseif n2 == 106
            q = 10/29;
            filename = strcat('NNMe0_10_29pp');
        elseif n2 == 107
            q = 11/29;
            filename = strcat('NNMe0_11_29pp');
        elseif n2 == 108
            q = 12/29;
            filename = strcat('NNMe0_12_29pp');
        elseif n2 == 109
            q = 13/29;
            filename = strcat('NNMe0_13_29pp');
        elseif n2 == 110
            q = 14/29;
            filename = strcat('NNMe0_14_29pp');
        elseif n2 == 111
            q = 1/31;
            filename = strcat('NNMe0_1_31pp');
        elseif n2 == 112
            q = 2/31;
            filename = strcat('NNMe0_2_31pp');
        elseif n2 == 113
            q = 3/31;
            filename = strcat('NNMe0_3_31pp');
        elseif n2 == 114
            q = 4/31;
            filename = strcat('NNMe0_4_31pp');
        elseif n2 == 115
            q = 5/31;
            filename = strcat('NNMe0_5_31pp');
        elseif n2 == 116
            q = 6/31;
            filename = strcat('NNMe0_6_31pp');
        elseif n2 == 117
            q = 7/31;
            filename = strcat('NNMe0_7_31pp');
        elseif n2 == 118
            q = 8/31;
            filename = strcat('NNMe0_8_31pp');
        elseif n2 == 119
            q = 9/31;
            filename = strcat('NNMe0_9_31pp');
        elseif n2 == 120
            q = 10/31;
            filename = strcat('NNMe0_10_31pp');
        elseif n2 == 121
            q = 11/31;
            filename = strcat('NNMe0_11_31pp');
        elseif n2 == 122
            q = 12/31;
            filename = strcat('NNMe0_12_31pp');
        elseif n2 == 123
            q = 13/31;
            filename = strcat('NNMe0_13_31pp');
        elseif n2 == 124
            q = 14/31;
            filename = strcat('NNMe0_14_31pp');
        elseif n2 == 125
            q = 1/45;
            filename = strcat('NNMe0_1_45pp');
        elseif n2 == 126
            q = 1/63;
            filename = strcat('NNMe0_1_63pp');
        elseif n2 == 127
            q = 1/125;
            filename = strcat('NNMe0_1_125pp');
        elseif n2 == 128
            q = 1/91;
            filename = strcat('NNMe0_1_91pp');
        elseif n2 == 129
            q = 22/45;
            filename = strcat('NNMe0_22_45pp');
        elseif n2 == 130
            q = 31/63;
            filename = strcat('NNMe0_31_63pp');
        elseif n2 == 131
            q = 62/125;
            filename = strcat('NNMe0_62_125pp');
        elseif n2 == 132
            q = 45/91;
            filename = strcat('NNMe0_45_91pp');
        elseif n2 == 133
            q = 25/51;
            filename = strcat('NNMe0_25_51pp');
        elseif n2 == 134
            q = 26/53;
            filename = strcat('NNMe0_26_53pp');
        elseif n2 == 135
            q = 27/55;
            filename = strcat('NNMe0_27_55pp');
        elseif n2 == 136
            q = 28/57;
            filename = strcat('NNMe0_28_57pp');
        else
            % disp(n2);
            break
        end
        load(filename);
        label1 = size(NNM,1)/4;
        NNMtemp = NNM;
        
        Adiff = nan(2,1);
        for n1 = 1:size(NNMtemp,1)/4
            Adiff(n1) = abs(NNMtemp(4*(n1-1)+2,1)-A);
        end
        [minAdiff,minAdiffLabel] = min(Adiff);
        
        NNMAtemp = nan(1,11);
        
        if n3 == size(Asample,2)
            tola = tola2;
        else
            tola = tola1;
        end
        
        
        
        if minAdiff < tola2
            if q == 0 || q == 1/2
                flagRec = 1;
            elseif NNM(4*(minAdiffLabel-1)+2,3) < tolUp2
                flagRec = 1;
            else
                flagRec = 0;
            end
            
            if flagRec == 1
                n2RecLabel = n2RecLabel+1;
                n2Rec(n2RecLabel) = n2;
                % disp(n2);
                labelWN = labelWN+1;
                waveNumRec(labelWN,1) = n2;
                waveNumRec(labelWN,2) = NNM(4*(minAdiffLabel-1)+2,3);
                
                
                NNMAtemp(1,11) = minAdiff;
                NNMAtemp(1,1) = NNM(4*(minAdiffLabel-1)+2,1);
                NNMAtemp(1,2) = q;
                NNMAtemp(1,3) = NNM(4*(minAdiffLabel-1)+2,2);
                %             if abs(NNM(4*(minAdiffLabel-1)+2,2)-1.0557) < 2e-4
                %                 disp(n2);
                %             end
                if q ~= 1/2
                    NNMAtemp(1,4) = NNM(4*(minAdiffLabel-1)+3,1);
                    NNMAtemp(1,5:8) = NNM(4*(minAdiffLabel-1)+4,1:4);
                    NNMAtemp(1,9) = NNM(2,4);
                    NNMAtemp(1,10) = NNM(2,5);
                else
                    NNMAtemp(1,9) = sw;
                end
                
                %             NNMAtemp(2,:) = NNMAtemp(1,:);
                %             NNMAtemp(2,2) = 1-q;
                
                if ~isnan(NNMAtemp(1,1))
                    label = label+1;
                    NNMAtemp2(label,:) = NNMAtemp(1,:);
                    %                 label = label+1;
                    %                 NNMAtemp2(label,:) = NNMAtemp(2,:);
                    labelTot = labelTot+1;
                    NNMAtot(labelTot,:) = NNMAtemp(1,:);
                    %                 labelTot = labelTot+1;
                    %                 NNMAtot(labelTot,:) = NNMAtemp(2,:);
                else
                    disp(n2);
                end
            end
        else
            % disp(n2);
        end
    end
    
    NNMA = nan(size(NNMAtemp2,1),size(NNMAtemp2,2));
    [qsort,Isort] = sort(NNMAtemp2(:,2));
    for n1 = 1:size(NNMAtemp2,1)
        NNMA(n1,:) = NNMAtemp2(Isort(n1),:);
    end
    
    NNMA1 = nan(2,size(NNMA,2));
    NNMA2 = nan(2,size(NNMA,2));
    label1 = 0;
    label2 = 0;
    for n1 = 1:size(NNMA,1)
        if NNMA(n1,3) >= wc
            label1 = label1+1;
            NNMA1(label1,:) = NNMA(n1,:);
        else
            label2 = label2+1;
            NNMA2(label2,:) = NNMA(n1,:);
        end
    end
    
    figure(n3); clf;
    hold on;
    for n4 = 1:size(NNMA1,1)
        plot(NNMA1(n4,2),NNMA1(n4,3),'r.')
    end
    for n4 = 1:size(NNMA2,1)
        plot(NNMA2(n4,2),NNMA2(n4,3),'b.')
    end
    hold off;
    
end















% figure(1000); clf;
% hold on;
% for n4 = 1:size(NNMAtot,1)
%     if NNMAtot(n4,9) == 1
%         plot(NNMAtot(n4,2),NNMAtot(n4,3),'b.')
%     elseif NNMAtot(n4,9) == -1
%         plot(NNMAtot(n4,2),NNMAtot(n4,3),'r.')
%     end
% end
% hold off;


NNMAtotTemp1S = nan(1000,11,size(Asample,2));
NNMAtotTemp2S = nan(1000,11,size(Asample,2));
% NNMAtotTemp1SMir = nan(100,11,size(Asample,2));
% NNMAtotTemp2SMir = nan(100,11,size(Asample,2));

NNMAfit1 = nan(2,2,size(Asample,2));
NNMAfit2 = nan(2,2,size(Asample,2));
% NNMAfit1Mir = nan(2,2,size(Asample,2));
% NNMAfit2Mir = nan(2,2,size(Asample,2));

figure(1001); clf;
hold on;

e0 = 0; %1.5;
c1 = 0.25; %2.25
c2 = 0.37; %2.37
% wChangeFac = 1;

% d = 0;
% d1 = 1.43; % 1.43
% d2 = scd*0.02;

label = 0;
wLinear1 = zeros(2,2);
wLinear2 = zeros(2,2);
for qTemp = 0:dq2Pi:0.5
    label = label+1;
    wLinear1(label,1) = qTemp;
    wLinear1(label,2) = e0+sqrt(c1^2+c2^2+2*c1*c2*cos(qTemp*2*pi));
    wLinear2(label,1) = qTemp;
    wLinear2(label,2) = e0-sqrt(c1^2+c2^2+2*c1*c2*cos(qTemp*2*pi));
end

plot(wLinear1(:,1),wLinear1(:,2),'c-')
plot(wLinear2(:,1),wLinear2(:,2),'c-')

for n1 = 1:size(Asample,2)
    if n1 == size(Asample,2)
        tola = tola2;
    else
        tola = tola1;
    end
    A = Asample(n1);
    if ~isnan(A)
        NNMAtotTemp1 = nan(2,size(NNMAtot,2));
        NNMAtotTemp2 = nan(2,size(NNMAtot,2));
        label1 = 0;
        label2 = 0;
        for n4 = 1:size(NNMAtot,1)
            if abs(NNMAtot(n4,1)-A) < tola
                if NNMAtot(n4,3) >= wc
                    label1 = label1+1;
                    NNMAtotTemp1(label1,:) = NNMAtot(n4,:);
                elseif NNMAtot(n4,3) < wc
                    label2 = label2+1;
                    NNMAtotTemp2(label2,:) = NNMAtot(n4,:);
                end
            end
        end
        [NNMAtotSort1,I1] = sort(NNMAtotTemp1(:,2));
        [NNMAtotSort2,I2] = sort(NNMAtotTemp2(:,2));
        
        
        for n10 = 1:size(NNMAtotTemp1,1)
            NNMAtotTemp1S(n10,:,n1) = NNMAtotTemp1(I1(n10),:);
        end

        
        
        for n10 = 1:size(NNMAtotTemp2,1)
            NNMAtotTemp2S(n10,:,n1) = NNMAtotTemp2(I2(n10),:);
        end

        
        NNMlength1 = 0;
        for n10 = 1:size(NNMAtotTemp1S,1)
            if ~isnan(NNMAtotTemp1S(n10,1,n1))
                NNMlength1 = NNMlength1+1;
            end
        end
        % p1 = polyfit(NNMAtotTemp1S(1:NNMlength1,2,n1),NNMAtotTemp1S(1:NNMlength1,3,n1),polyOrder1);
        
        NNMlength2 = 0;
        for n10 = 1:size(NNMAtotTemp2S,1)
            if ~isnan(NNMAtotTemp2S(n10,1,n1))
                NNMlength2 = NNMlength2+1;
            end
        end
        % p2 = polyfit(NNMAtotTemp2S(1:NNMlength2,2,n1),NNMAtotTemp2S(1:NNMlength2,3,n1),polyOrder2);
        
%         labelNNMfit = 0;
%         
%         for qTemp = 0:dq2Pi:0.5
%             labelNNMfit = labelNNMfit+1;
%             NNMAfit1(labelNNMfit,1,n1) = qTemp;
%             NNMAfit1(labelNNMfit,2,n1) = 0;
%             
%             for n13 = 1:polyOrder1+1
%                 NNMAfit1(labelNNMfit,2,n1) = NNMAfit1(labelNNMfit,2,n1)+p1(n13)*qTemp^(polyOrder1+1-n13);
%             end
%             
%             NNMAfit2(labelNNMfit,1,n1) = qTemp;
%             NNMAfit2(labelNNMfit,2,n1) = 0;
%             
%             for n13 = 1:polyOrder2+1
%                 NNMAfit2(labelNNMfit,2,n1) = NNMAfit2(labelNNMfit,2,n1)+p2(n13)*qTemp^(polyOrder2+1-n13);
%             end
%         end
        
%         plot(NNMAfit1(:,1,n1),NNMAfit1(:,2,n1),'b-','color',coloring(n1,:))
%         plot(NNMAfit2(:,1,n1),NNMAfit2(:,2,n1),'r-','color',coloring(n1,:))
        
        plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','color',coloring(n1,:))
        plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.-','color',coloring(n1,:))
        
    end
    
    plot([0 0.5],[1.5 1.5],'k--')
end
hold off;





figure(1002); clf;
hold on;

H2 = plot([10 10],[0 10],'b.-','linewidth',lineWidth*3,'markersize',markerSize*3);
H3 = plot([10 10],[0 10],'r.-','linewidth',lineWidth*3,'markersize',markerSize*3);
H1 = plot([10 10],[0 10],'k-','linewidth',lineWidth*3,'markersize',markerSize*3,'color',[255 165 0]/256);

n1 = 1;
plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize);
plot(NNMAtotTemp1S(:,2,n1),-NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
plot(1-NNMAtotTemp1S(:,2,n1),-NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)

n1 = 2;
plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize);
plot(NNMAtotTemp1S(:,2,n1),-NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
plot(1-NNMAtotTemp1S(:,2,n1),-NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
for ntemp1 = 1:size(NNMAtotTemp1S,1)
    if abs(NNMAtotTemp1S(ntemp1,2,n1)-4/9) < 1e-6
        xP = NNMAtotTemp1S(ntemp1,2,n1);
        yP = NNMAtotTemp1S(ntemp1,3,n1);
        % plot(NNMAtotTemp1S(ntemp1,2,n1),NNMAtotTemp1S(ntemp1,3,n1),'k.-','linewidth',lineWidth,'markersize',markerSize);
        break
    end
end

plot(wLinear1(:,1),wLinear1(:,2),'k-','linewidth',lineWidth*1.5,'markersize',markerSize,'color',[255 165 0]/256);
plot(wLinear2(:,1),wLinear2(:,2),'k-','linewidth',lineWidth*1.5,'markersize',markerSize,'color',[255 165 0]/256)
plot(1-wLinear1(:,1),wLinear1(:,2),'k-','linewidth',lineWidth*1.5,'markersize',markerSize,'color',[255 165 0]/256)
plot(1-wLinear2(:,1),wLinear2(:,2),'k-','linewidth',lineWidth*1.5,'markersize',markerSize,'color',[255 165 0]/256)

% n1 = 3;
% H4 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'g.-','linewidth',lineWidth,'markersize',markerSize);
% plot(NNMAtotTemp1S(:,2,n1),-NNMAtotTemp1S(:,3,n1),'g.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'g.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp1S(:,2,n1),-NNMAtotTemp1S(:,3,n1),'g.-','linewidth',lineWidth,'markersize',markerSize)

% n1 = 4;
% H5 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize);
% plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'m.-','linewidth',lineWidth,'markersize',markerSize)
% 
% n1 = 5;
% H6 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'c.-','linewidth',lineWidth,'markersize',markerSize);
% plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'c.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'c.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'c.-','linewidth',lineWidth,'markersize',markerSize)


plot(xP,yP,'k.','markersize',20)
text(xP,yP-0.05,'P','horiz','center','color','k','fontsize',16,'Interpreter','latex')

plot([0 1],[0 0],'k--','linewidth',lineWidth*2)
axis([0 1 -0.7 0.7])
hold off;
xticks([0 0.5 1])
xticklabels({'0','\pi','2\pi'})
yticks([-0.5 0 0.5])
legend([H1 H2 H3],{'$A=0$','$A=0.2a_c$','$A=0.5a_c$'},'Location','north','FontSize',16,'Interpreter','latex');
% legend([H2 H3],{'$A=0$','$A=0.2a_c$','$A=0.5a_c$'},'Location','north','FontSize',16,'Interpreter','latex');
% legend([H1 H2 H3 H4 H5 H6],{'$A=0$','$A=0.1$','$A=0.3$','$A=0.5$','$A=0.7$','$A=A_c$'},'Location','north','FontSize',16,'Interpreter','latex');
% set(gca, 'YScale', 'log')
set(gca,'linewidth',2)
set(gca,'FontSize',19)
xlabel('$q$','Interpreter','latex')
ylabel('$\omega$','Interpreter','latex')







% figure(1003); clf;
% hold on;
% 
% % n1 = 2;
% % H1 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize);
% % plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% % plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% % plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% % 
% % n1 = 3;
% % H2 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize);
% % plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
% % plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
% % plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
% 
% plot([0 1],[1.5 1.5],'k--','linewidth',lineWidth)
% axis([0 1 0.5 2.3])
% hold off;
% xticks([0 0.5 1])
% yticks([0.5 1 1.5 2])
% legend([H1 H2],{'$A=0.85$','$A=A_c$'},'Location','south','FontSize',16,'Interpreter','latex');
% % set(gca, 'YScale', 'log')
% set(gca,'linewidth',2)
% set(gca,'FontSize',19)
% xlabel('$q$','Interpreter','latex')
% ylabel('$\omega$','Interpreter','latex')









% figure(1004); clf;
% hold on;
% 
% n1 = 4;
% H1 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize);
% plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'b.-','linewidth',lineWidth,'markersize',markerSize)
% 
% n1 = 5;
% H2 = plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize);
% plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
% plot(1-NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.-','linewidth',lineWidth,'markersize',markerSize)
% 
% plot([0 1],[1.5 1.5],'k--','linewidth',lineWidth)
% % axis([0 1 0.5 2.4])
% hold off;
% xticks([0 0.5 1])
% yticks([0.5 1 1.5 2])
% legend([H1 H2],{'$A=1$','$A=1.1$'},'Location','south','FontSize',16,'Interpreter','latex');
% % set(gca, 'YScale', 'log')
% set(gca,'linewidth',2)
% set(gca,'FontSize',19)
% xlabel('$q$','Interpreter','latex')
% ylabel('$\omega$','Interpreter','latex')