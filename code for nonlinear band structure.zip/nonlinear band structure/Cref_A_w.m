% w-A curve plot

tolqStd = 1e-2;
Ac = 0.894427190999916;

for n2 = 3
    % filename1 = strcat('NNM',num2str(n2),'pp');
    filename1 = strcat('NNM65_131pp');
    load(filename1);
    
    NNMtemp = NNM;
    NNM = nan(1,size(NNMtemp,2));
    
    NNMwA = nan(size(NNMtemp,1)/4,4);
    label1 = 0;
    nqStdOut = 0;
    for n = 1:size(NNMtemp,1)/4
        if std(NNMtemp(4*(n-1)+3,:)) < tolqStd && NNMtemp(4*(n-1)+3,1) ~= 0 % && n~=102 % && NNMtemp(4*(n-1)+2,2) < 1.7
            label1 = label1+1;
            NNMwA(label1,1) = NNMtemp(4*(n-1)+2,1); % A
            NNMwA(label1,2) = NNMtemp(4*(n-1)+2,2); % w
            NNMwA(label1,3) = NNMtemp(4*(n-1)+3,1); % q
            NNMwA(label1,4) = std(NNMtemp(4*(n-1)+3,:)); % std of q
            
            NNM(4*(label1-1)+1,:) = NNMtemp(4*(n-1)+1,:);
            NNM(4*(label1-1)+2,:) = NNMtemp(4*(n-1)+2,:);
            NNM(4*(label1-1)+3,:) = NNMtemp(4*(n-1)+3,:);
            NNM(4*(label1-1)+4,:) = NNMtemp(4*(n-1)+4,:);
        elseif NNMtemp(4*(n-1)+3,1) == 0
            %disp(n);
            disp(std(NNMtemp(4*(n-1)+3,:)));
            nqStdOut = nqStdOut+1;
        elseif std(NNMtemp(4*(n-1)+3,:)) >= tolqStd
            %disp(n);
            disp(std(NNMtemp(4*(n-1)+3,:)));
            nqStdOut = nqStdOut+1;
        end
    end
    disp(nqStdOut);
    
    figure(1); clf;
    hold on;
    plot(NNMwA(:,1),NNMwA(:,2),'b.')
    plot([Ac Ac],[min(NNMwA(:,2)) max(NNMwA(:,2))])
    plot([0.2 0.2],[min(NNMwA(:,2)) max(NNMwA(:,2))])
    plot([0.4 0.4],[min(NNMwA(:,2)) max(NNMwA(:,2))])
    plot([0.85 0.85],[min(NNMwA(:,2)) max(NNMwA(:,2))])
    plot([0.95 0.95],[min(NNMwA(:,2)) max(NNMwA(:,2))])
    plot([1 1],[min(NNMwA(:,2)) max(NNMwA(:,2))])
    plot([1.1 1.1],[min(NNMwA(:,2)) max(NNMwA(:,2))])
    axis([0 1.3 min(NNMwA(:,2)) max(NNMwA(:,2))])
    hold off;
    
    % see if there is any q outlier
    tolq = 1e-3;
    q = mean(NNMwA(:,3));
    nqOut = 0;
    for n1 = 1:size(NNMwA,1)
        if abs(NNMwA(n1,3)-q) > tolq
            nqOut = nqOut+1;
        end
    end
    disp(nqOut);
    disp(size(NNM,1)-size(NNMtemp,1));
    
    % save(filename1,'NNM');
end


min(NNM(4*(1-1)+2:4:4*(size(NNM,1)/4-1)+2,1))
max(NNM(4*(1-1)+2:4:4*(size(NNM,1)/4-1)+2,1))


largeTol = 0;
for n21 = 1:size(NNM,1)/4
    if NNM(4*(n21-1)+2,3) > 1e-6
        largeTol = largeTol+1;
        disp(n21*4);
        disp(NNM(4*(n21-1)+2,1));
    end
end

disp(largeTol);


% NNMtemp = NNM;
% NNM = zeros(4,size(NNMtemp,2));
% label = 0;
% for n = 1:size(NNMtemp,1)/4
%     if NNMtemp(4*(n-1)+2,2) < 1.5
%         label = label+1;
%         NNM(4*(label-1)+1,:) = NNMtemp(4*(n-1)+1,:);
%         NNM(4*(label-1)+2,:) = NNMtemp(4*(n-1)+2,:);
%         NNM(4*(label-1)+3,:) = NNMtemp(4*(n-1)+3,:);
%         NNM(4*(label-1)+4,:) = NNMtemp(4*(n-1)+4,:);
%     end
% end
        
        
        
        
        
        