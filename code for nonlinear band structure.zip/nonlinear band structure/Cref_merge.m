filename1 = strcat('NNM65_131pp2');
load(filename1);
label1 = size(NNM,1)/4;
NNMtemp = NNM;

filename2 = strcat('NNM65_131pp');
load(filename2);

label = size(NNM,1)/4;

for n = 1:label1
    NNM(4*(label+n-1)+1,:) = NNMtemp(4*(n-1)+1,:);
    NNM(4*(label+n-1)+2,:) = NNMtemp(4*(n-1)+2,:);
    NNM(4*(label+n-1)+3,:) = NNMtemp(4*(n-1)+3,:);
    NNM(4*(label+n-1)+4,:) = NNMtemp(4*(n-1)+4,:);
end

save(filename2,'NNM');


% NNMamptot1 = nan(2,3);
% NNMamptot2 = nan(2,3);
% label1 = 0;
% label2 = 0;
% 
% A1 = 0.85;
% A2 = 0.95;
% DAtol = 0.05;
% 
% for n1 = 1:6
%     filename1 = strcat('NNM',num2str(n1),'pp');
%     % filename1 = strcat('NNM1_3pp');
%     load(filename1);
%     
%     NNMampDiff1 = nan(size(NNM,1)/4,4);
%     NNMampDiff2 = nan(size(NNM,1)/4,4);
%     
%     for n = 1:size(NNM,1)/4
%         NNMampDiff1(n,1) = abs(NNM(4*(n-1)+2,1)-A1); % |A-A1|
%         NNMampDiff1(n,2) = NNM(4*(n-1)+2,1); % A
%         NNMampDiff1(n,3) = NNM(4*(n-1)+2,2); % w
%         NNMampDiff1(n,4) = NNM(4*(n-1)+3,1); % q
%         
%         NNMampDiff2(n,1) = abs(NNM(4*(n-1)+2,1)-A2); % |A-A2|
%         NNMampDiff2(n,2) = NNM(4*(n-1)+2,1); % A
%         NNMampDiff2(n,3) = NNM(4*(n-1)+2,2); % w
%         NNMampDiff2(n,4) = NNM(4*(n-1)+3,1); % q
%     end
%     
%     [NNMamp1,NNMampLabel1] = min(NNMampDiff1(:,1));
%     [NNMamp2,NNMampLabel2] = min(NNMampDiff2(:,1));
%     
%     if NNMamp1 < DAtol
%         label1 = label1+1;
%         NNMamptot1(label1,1) = NNMampDiff1(NNMampLabel1,2); % A
%         NNMamptot1(label1,2) = NNMampDiff1(NNMampLabel1,3); % w
%         NNMamptot1(label1,3) = NNMampDiff1(NNMampLabel1,4); % q
%     end
%     
%     if NNMamp2 < DAtol
%         label2 = label2+1;
%         NNMamptot2(label2,1) = NNMampDiff2(NNMampLabel2,2); % A
%         NNMamptot2(label2,2) = NNMampDiff2(NNMampLabel2,3); % w
%         NNMamptot2(label2,3) = NNMampDiff2(NNMampLabel2,4); % q
%     end
%     
% end
% 
% 
% 
% 
% 
% 
% for n1 = 1:6
%     filename1 = strcat('NNM',num2str(n1),'mp');
%     % filename1 = strcat('NNM1_3pp');
%     load(filename1);
%     
%     NNMampDiff1 = nan(size(NNM,1)/4,4);
%     NNMampDiff2 = nan(size(NNM,1)/4,4);
%     
%     for n = 1:size(NNM,1)/4
%         NNMampDiff1(n,1) = abs(NNM(4*(n-1)+2,1)-A1); % |A-A1|
%         NNMampDiff1(n,2) = NNM(4*(n-1)+2,1); % A
%         NNMampDiff1(n,3) = NNM(4*(n-1)+2,2); % w
%         NNMampDiff1(n,4) = NNM(4*(n-1)+3,1); % q
%         
%         NNMampDiff2(n,1) = abs(NNM(4*(n-1)+2,1)-A2); % |A-A2|
%         NNMampDiff2(n,2) = NNM(4*(n-1)+2,1); % A
%         NNMampDiff2(n,3) = NNM(4*(n-1)+2,2); % w
%         NNMampDiff2(n,4) = NNM(4*(n-1)+3,1); % q
%     end
%     
%     [NNMamp1,NNMampLabel1] = min(NNMampDiff1(:,1));
%     [NNMamp2,NNMampLabel2] = min(NNMampDiff2(:,1));
%     
%     if NNMamp1 < DAtol
%         label1 = label1+1;
%         NNMamptot1(label1,1) = NNMampDiff1(NNMampLabel1,2); % A
%         NNMamptot1(label1,2) = NNMampDiff1(NNMampLabel1,3); % w
%         NNMamptot1(label1,3) = NNMampDiff1(NNMampLabel1,4); % q
%     end
%     
%     if NNMamp2 < DAtol
%         label2 = label2+1;
%         NNMamptot2(label2,1) = NNMampDiff2(NNMampLabel2,2); % A
%         NNMamptot2(label2,2) = NNMampDiff2(NNMampLabel2,3); % w
%         NNMamptot2(label2,3) = NNMampDiff2(NNMampLabel2,4); % q
%     end
%     
% end
% 
% 
% 
% 
% 
% 
% 
% for n1 = 1:6
%     filename1 = strcat('NNM',num2str(n1),'mp');
%     % filename1 = strcat('NNM1_3pp');
%     load(filename1);
%     
%     NNMampDiff1 = nan(size(NNM,1)/4,4);
%     NNMampDiff2 = nan(size(NNM,1)/4,4);
%     
%     for n = 1:size(NNM,1)/4
%         NNMampDiff1(n,1) = abs(NNM(4*(n-1)+2,1)-A1); % |A-A1|
%         NNMampDiff1(n,2) = NNM(4*(n-1)+2,1); % A
%         NNMampDiff1(n,3) = NNM(4*(n-1)+2,2); % w
%         NNMampDiff1(n,4) = NNM(4*(n-1)+3,1); % q
%         
%         NNMampDiff2(n,1) = abs(NNM(4*(n-1)+2,1)-A2); % |A-A2|
%         NNMampDiff2(n,2) = NNM(4*(n-1)+2,1); % A
%         NNMampDiff2(n,3) = NNM(4*(n-1)+2,2); % w
%         NNMampDiff2(n,4) = NNM(4*(n-1)+3,1); % q
%     end
%     
%     [NNMamp1,NNMampLabel1] = min(NNMampDiff1(:,1));
%     [NNMamp2,NNMampLabel2] = min(NNMampDiff2(:,1));
%     
%     if NNMamp1 < DAtol
%         label1 = label1+1;
%         NNMamptot1(label1,1) = NNMampDiff1(NNMampLabel1,2); % A
%         NNMamptot1(label1,2) = NNMampDiff1(NNMampLabel1,3); % w
%         NNMamptot1(label1,3) = NNMampDiff1(NNMampLabel1,4); % q
%     end
%     
%     if NNMamp2 < DAtol
%         label2 = label2+1;
%         NNMamptot2(label2,1) = NNMampDiff2(NNMampLabel2,2); % A
%         NNMamptot2(label2,2) = NNMampDiff2(NNMampLabel2,3); % w
%         NNMamptot2(label2,3) = NNMampDiff2(NNMampLabel2,4); % q
%     end
%     
% end
% 
% 
% 
