Ac = 0.894427190999916;
tolA1 = 4e-3;
e0 = 1.5;
dq2Pi = 0.5/200; % wave number in units of 2pi   0.5 corresponds to pi
polyOrder  = 4;
polyOrder1 = polyOrder;
polyOrder2 = polyOrder;

pmmmSswitch = 1;
NNMAtot = nan(30,10); % 1:A, 2:q, 3:w, 4:InterPhase, 5,6,7,8:IntraPhase, 9,10:pp,pm,mp,mm
labelTot = 0;
Asample = [0.2 0.85 Ac 0.95 1.1];
for n3 = 1:size(Asample,2)
    NNMA = nan(30,10); % 1:A, 2:q, 3:w, 4:InterPhase, 5,6,7,8:IntraPhase, 9,10:pp,pm,mp,mm
    A = Asample(n3);
%     if n3 == 1
%         A = 1.1;
%     elseif n3 == 2
%         A = 0.95;
%     elseif n3 == 3
%         A = Ac;
%     elseif n3 == 4
%         A = 0.85;
%     elseif n3 == 5
%         A = 0.2;
%     end
    tolA = A*tolA1;
    
    label = 0;
    % filename1 = strcat('.\Kagome_lattice\Kagome_Diode\Kagome_diode_fine_in_0_125_',num2str(i));
    n2 = 0;
    while 1
        n2 = n2+1;
        if n2 == 1
            q = 1/2;
            sw = +1;
            filename = strcat('NNM1_2pp');
        elseif n2 == 2
            q = 1/2;
            sw = -1;
            filename = strcat('NNM1_2mp');
        elseif n2 == 3
            q = 1/3;
            filename = strcat('NNM1_3pp');
        elseif n2 == 4
            q = 1/3;
            filename = strcat('NNM1_3mp');
        elseif n2 == 5
            q = 1/4;
            filename = strcat('NNM1_4pp');
        elseif n2 == 6
            q = 1/4;
            filename = strcat('NNM1_4mp');
        elseif n2 == 7
            q = 1/5;
            filename = strcat('NNM1_5pp');
        elseif n2 == 8
            q = 1/5;
            filename = strcat('NNM1_5mp');
        elseif n2 == 9
            q = 1/7;
            filename = strcat('NNM1_7pp');
        elseif n2 == 10
            q = 1/7;
            filename = strcat('NNM1_7mp');
        elseif n2 == 11
            q = 1/9;
            filename = strcat('NNM1_9pp');
        elseif n2 == 12
            continue;
            %         q = 1/9;
            %         filename = strcat('NNM1_9mp');
        elseif n2 == 13
            q = 2/5;
            filename = strcat('NNM2_5pp');
        elseif n2 == 14
            q = 2/5;
            filename = strcat('NNM2_5mp');
        elseif n2 == 15
            continue;
            %         q = 2/7;
            %         filename = strcat('NNM2_7pp');
        elseif n2 == 16
            q = 2/7;
            filename = strcat('NNM2_7mp');
        elseif n2 == 17
            q = 2/9;
            filename = strcat('NNM2_9pp');
        elseif n2 == 18
            q = 2/9;
            filename = strcat('NNM2_9mp');
        elseif n2 == 19
            q = 2/11;
            filename = strcat('NNM2_11pp');
        elseif n2 == 20
            q = 2/11;
            filename = strcat('NNM2_11mp');
        elseif n2 == 21
            q = 3/7;
            filename = strcat('NNM3_7pp');
        elseif n2 == 22
            q = 3/7;
            filename = strcat('NNM3_7mp');
        elseif n2 == 23
            continue;
            %         q = 3/11;
            %         filename = strcat('NNM3_11pp');
        elseif n2 == 24
            q = 3/11;
            filename = strcat('NNM3_11mp');
        elseif n2 == 25
            continue;
            %         q = 5/11;
            %         filename = strcat('NNM5_11pp');
        elseif n2 == 26
            q = 5/11;
            filename = strcat('NNM5_11mp');
        elseif n2 == 27
            q = 4/9;
            filename = strcat('NNM4_9pp');
        elseif n2 == 28
            continue;
            %         q = 4/9;
            %         filename = strcat('NNM4_9mp');
        elseif n2 == 29
            if pmmmSswitch == 1
                q = abs(1/3-1/2);
                filename = strcat('NNM1_3pm');
            end
        elseif n2 == 30
            if pmmmSswitch == 1
                q = abs(1/9-1/2);
                filename = strcat('NNM1_9pm');
            end
        elseif n2 == 31
            if pmmmSswitch == 1
                q = abs(2/5-1/2);
                filename = strcat('NNM2_5pm');
            end
        elseif n2 == 32
            if pmmmSswitch == 1
                q = abs(2/9-1/2);
                filename = strcat('NNM2_9pm');
            end
        elseif n2 == 33
            if pmmmSswitch == 1
                q = abs(3/7-1/2);
                filename = strcat('NNM3_7pm');
            end
        elseif n2 == 34
            if pmmmSswitch == 1
                q = abs(1/3-1/2);
                filename = strcat('NNM1_3mm');
            end
        elseif n2 == 35
            if pmmmSswitch == 1
                q = abs(1/5-1/2);
                filename = strcat('NNM1_5mm');
            end
        elseif n2 == 36
            if pmmmSswitch == 1
                q = abs(1/7-1/2);
                filename = strcat('NNM1_7mm');
            end
        elseif n2 == 37
            if pmmmSswitch == 1
                q = abs(1/9-1/2);
                filename = strcat('NNM1_9mm');
            end
        elseif n2 == 38
            if pmmmSswitch == 1
                q = abs(3/7-1/2);
                filename = strcat('NNM3_7mm');
            end
        elseif n2 == 39
            q = 3/13;
            filename = strcat('NNM3_13pp');
        elseif n2 == 40
            q = 6/13;
            filename = strcat('NNM6_13pp');
        elseif n2 == 41
            q = 3/13;
            filename = strcat('NNM3_13mp');
        elseif n2 == 42
            q = 4/13;
            filename = strcat('NNM4_13mp');
        elseif n2 == 43
            q = 5/13;
            filename = strcat('NNM5_13mp');
        elseif n2 == 44
            if pmmmSswitch == 1
                q = abs(1/13-1/2);
                filename = strcat('NNM1_13mm');
            end
        elseif n2 == 45
            q = abs(7/15);
            filename = strcat('NNM7_15pp');
        elseif n2 == 46
            q = abs(0);
            filename = strcat('NNM0pp');
        elseif n2 == 47
            q = abs(0);
            filename = strcat('NNM0mp');
        else
            break
        end
        load(filename);
        label1 = size(NNM,1)/4;
        NNMtemp = NNM;
        
        NNMAtemp = nan(1,10);
        diffA = 1e10;
%         if n2 == 2 && abs(A-Ac) < tolA
%             diffW = 1e10;
%             for n15 = 1:size(NNM)/4
%                 diffWtemp = NNM(4*(n15-1)+2,2)-e0;
%                 if abs(diffWtemp) < abs(diffW) && diffWtemp < 0
%                     n2Pick = n15;
%                     diffW = diffWtemp;
%                 end
%             end
%             NNMAtemp(1) = NNM(4*(n2Pick-1)+2,1);
%             x2 = NNM(4*(n2Pick-1)+2,1);
%             NNMAtemp(2) = q;
%             NNMAtemp(3) = NNM(4*(n2Pick-1)+2,2);
%             x1 = NNM(4*(n2Pick-1)+2,2);
%             NNMAtemp(9) = sw;
%         else
            for n1 = 1:size(NNM,1)/4
                if abs(NNM(4*(n1-1)+2,1)-A) < tolA && abs(NNM(4*(n1-1)+2,1)-A) < diffA
                    diffA = abs(NNM(4*(n1-1)+2,1)-A);
                    NNMAtemp(1) = NNM(4*(n1-1)+2,1);
                    NNMAtemp(2) = q;
                    
                    NNMAtemp(3) = NNM(4*(n1-1)+2,2);
                    if q ~= 1/2
                        NNMAtemp(4) = NNM(4*(n1-1)+3,1);
                        NNMAtemp(5:8) = NNM(4*(n1-1)+4,1:4);
                        NNMAtemp(9) = NNM(2,4);
                        NNMAtemp(10) = NNM(2,5);
                    else
                        NNMAtemp(9) = sw;
                    end
                    
                end
            end
%         end
        if ~isnan(NNMAtemp(1))
            label = label+1;
            NNMA(label,:) = NNMAtemp(:);
            labelTot = labelTot+1;
            NNMAtot(labelTot,:) = NNMAtemp(:);
        else
            disp(n2);
        end
    end
    figure(n3); clf;
    hold on;
    for n4 = 1:size(NNMA,1)
        if NNMA(n4,9) == 1
            plot(NNMA(n4,2),NNMA(n4,3),'b.')
        elseif NNMA(n4,9) == -1
            plot(NNMA(n4,2),NNMA(n4,3),'r.')
        end
    end
    hold off;
end


        

% figure(1000); clf;
% hold on;
% for n4 = 1:size(NNMAtot,1)
%     if NNMAtot(n4,9) == 1
%         plot(NNMAtot(n4,2),NNMAtot(n4,3),'b.')
%     elseif NNMAtot(n4,9) == -1
%         plot(NNMAtot(n4,2),NNMAtot(n4,3),'r.')
%     end
% end
% hold off;


NNMAtotTemp1S = nan(100,10,size(Asample,2));
NNMAtotTemp2S = nan(100,10,size(Asample,2));
NNMAfit1 = nan(2,2,size(Asample,2));
NNMAfit2 = nan(2,2,size(Asample,2));
    
figure(1001); clf;
hold on;
for n1 = 1:size(Asample,2)
    A = Asample(n1);
    NNMAtotTemp1 = nan(2,size(NNMAtot,2));
    NNMAtotTemp2 = nan(2,size(NNMAtot,2));
    label1 = 0;
    label2 = 0;
    for n4 = 1:size(NNMAtot,1)
        if abs(NNMAtot(n4,1)-A) < tolA
            if NNMAtot(n4,3) >= e0
                label1 = label1+1;
                NNMAtotTemp1(label1,:) = NNMAtot(n4,:);
            elseif NNMAtot(n4,3) < e0
                label2 = label2+1;
                NNMAtotTemp2(label2,:) = NNMAtot(n4,:);
            end
        end
    end
    [NNMAtotSort1,I1] = sort(NNMAtotTemp1(:,2));
    [NNMAtotSort2,I2] = sort(NNMAtotTemp2(:,2));
    
    
    for n10 = 1:size(NNMAtotTemp1,1)
        NNMAtotTemp1S(n10,:,n1) = NNMAtotTemp1(I1(n10),:);
    end
    for n10 = 1:size(NNMAtotTemp2,1)
        NNMAtotTemp2S(n10,:,n1) = NNMAtotTemp2(I2(n10),:);
    end
    
    NNMlength1 = 0;
    for n10 = 1:size(NNMAtotTemp1S,1)
        if ~isnan(NNMAtotTemp1S(n10,1,n1))
            NNMlength1 = NNMlength1+1;
        end
    end
    p1 = polyfit(NNMAtotTemp1S(1:NNMlength1,2,n1),NNMAtotTemp1S(1:NNMlength1,3,n1),polyOrder1);
    
    NNMlength2 = 0;
    for n10 = 1:size(NNMAtotTemp2S,1)
        if ~isnan(NNMAtotTemp2S(n10,1,n1))
            NNMlength2 = NNMlength2+1;
        end
    end
    p2 = polyfit(NNMAtotTemp2S(1:NNMlength2,2,n1),NNMAtotTemp2S(1:NNMlength2,3,n1),polyOrder2);
    
    labelNNMfit = 0;
    
    for qTemp = 0:dq2Pi:0.5
        labelNNMfit = labelNNMfit+1;
        NNMAfit1(labelNNMfit,1,n1) = qTemp;
        NNMAfit1(labelNNMfit,2,n1) = 0;
        
        for n13 = 1:polyOrder1+1
            NNMAfit1(labelNNMfit,2,n1) = NNMAfit1(labelNNMfit,2,n1)+p1(n13)*qTemp^(polyOrder1+1-n13);
        end
        
        NNMAfit2(labelNNMfit,1,n1) = qTemp;
        NNMAfit2(labelNNMfit,2,n1) = 0;
        
        for n13 = 1:polyOrder2+1
            NNMAfit2(labelNNMfit,2,n1) = NNMAfit2(labelNNMfit,2,n1)+p2(n13)*qTemp^(polyOrder2+1-n13);
        end
    end
    plot(NNMAfit1(:,1,n1),NNMAfit1(:,2,n1),'b-')
    plot(NNMAfit2(:,1,n1),NNMAfit2(:,2,n1),'r-')  
    
    plot(NNMAtotTemp1S(:,2,n1),NNMAtotTemp1S(:,3,n1),'b.')
    plot(NNMAtotTemp2S(:,2,n1),NNMAtotTemp2S(:,3,n1),'r.')
end
hold off;
